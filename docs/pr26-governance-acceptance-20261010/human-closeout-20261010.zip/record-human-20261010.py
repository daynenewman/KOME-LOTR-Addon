from pathlib import Path
import datetime, hashlib, json, shutil, struct, zipfile

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
image_source = Path('C:/Users/dayne/AppData/Local/Temp/codex-clipboard-867ee5d4-b4de-4be7-982f-a59b10b6c50c.png')
image = root / 'human-governance-20261010.png'
if image.exists():
    assert sha(image) == sha(image_source)
else:
    shutil.copy2(image_source, image)
raw = image.read_bytes()
assert raw[:8] == b'\x89PNG\r\n\x1a\n'
dimensions = struct.unpack('>II', raw[16:24])
for current, archived in [('human-observation.json', 'human-observation-pending-20261009.json'),
        ('validation.json', 'validation-native-20261009.json'), ('evidence.zip', 'evidence-native-20261009.zip')]:
    if not (root / archived).exists():
        shutil.copy2(root / current, root / archived)
observed_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
human = json.loads((root / 'human-observation-pending-20261009.json').read_text(encoding='utf-8'))
proof_file = root / 'screenshot-session-proof-20261010.txt'
proof = proof_file.read_text(encoding='utf-8')
assert 'PASS CONNECTED identity=_Danye_' in proof
assert 'PASS PANEL tile=T388 conflict=CF1 revision=4 reason=GOVERNANCE_RESTRICTED' in proof
assert 'joinEnabled=false connected=true' in proof
human.update({
    'status': 'PASS_SCOPED_GOVERNANCE_PANEL', 'recorded_at_utc': observed_at,
    'reply_type': 'USER_SUPPLIED_SCREENSHOT', 'reply': 'Screenshot attachment; no verbal yes/no reply supplied.',
    'screenshot': {'file': image.name, 'sha256': sha(image), 'width': dimensions[0], 'height': dimensions[1]},
    'human_observed': {'tile': 'T388', 'conflict': 'CF1', 'revision': 4, 'state': 'ORDINARY',
        'faction': 'gondor', 'panel_status': 'BLOCKED',
        'reason_text': 'Your current war governance status prevents Join Battle participation.',
        'select_join_battle_disabled': True, 'no_eligible_rows_displayed': True},
    'native_current_session': {'evidence': proof_file.name, 'sha256': sha(proof_file),
        'client_pid': 45260, 'server_pid': 47508, 'connected': True,
        'loaded_client_server_sha256': human['candidate_sha256'], 'non_operator_server_verified': True,
        'read_only': True, 'commands_sent': 0},
    'interpretation': 'Human screenshot confirms exact active-conflict governance denial and disabled Join. Subsequent read-only native inspection independently confirms the matching authenticated session stays connected.',
    'limits': 'One authenticated non-operator and synthetic registered company baseline. No physical battle entry, full defeat predicate, multiplayer or representative lower-spec acceptance. Fixture retained; no product defect or rebuild.'
})
(root / 'human-observation.json').write_text(json.dumps(human, indent=2) + '\n', encoding='utf-8')
validation = json.loads((root / 'validation-native-20261009.json').read_text(encoding='utf-8'))
validation['human_observation'] = human
validation['human_closeout_20261010'] = {'recorded_at_utc': observed_at,
    'scope': 'Join Battle submitted-governance panel denial', 'result': 'PASS',
    'human': 'Screenshot of exact denial and disabled Join', 'native': 'Read-only current connected identity/candidate/panel and non-operator verification',
    'fixture_recreated': False, 'product_source_changes': False, 'product_rebuild': False,
    'publication': 'Local evidence retained; no PR push, merge or deployment in this closeout.'}
validation['limits'] = [line.replace('human observation remains separate.', 'human screenshot observation remains separate from native connected-session verification.') for line in validation['limits']]
(root / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n', encoding='utf-8')
server = root.parent / 'runtime/server'
profile = Path(validation['candidate']['profile']) / 'minecraft'
for source, target in [(server / 'logs/latest.log', 'server-human-20261010.log'),
        (profile / 'logs/latest.log', 'client-human-20261010.log')]:
    lines = source.read_text(encoding='utf-8', errors='replace').splitlines()
    (root / target).write_text('\n'.join(lines[-30:]) + '\n', encoding='utf-8')
entries = sorted(p for p in root.iterdir() if p.is_file() and p.name not in ['evidence.zip', 'evidence-native-20261009.zip', 'human-closeout-20261010.json'])
archive = root / 'human-closeout-20261010.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in entries:
        if p.suffix in ['.json', '.png', '.txt', '.log', '.dat', '.java', '.py', '.md', '.cfg', '.properties']:
            z.write(p, p.name)
result = {'recorded_at_utc': observed_at, 'result': 'PASS_SCOPED_GOVERNANCE_PANEL',
    'candidate_sha256': human['candidate_sha256'], 'human': human,
    'archive': archive.name, 'archive_sha256': sha(archive),
    'preserved_native_archive': {'file': 'evidence-native-20261009.zip', 'sha256': sha(root / 'evidence-native-20261009.zip')},
    'published': False, 'multiplayer': 'DEFERRED',
    'files': {p.name: sha(p) for p in entries if p.suffix in ['.json', '.png', '.txt', '.log', '.dat', '.java', '.py', '.md', '.cfg', '.properties']}}
(root / 'human-closeout-20261010.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'human_panel': 'PASS', 'native_current_connection': 'PASS',
    'candidate': human['candidate_sha256'], 'screenshot_sha256': sha(image), 'archive_sha256': sha(archive)}))

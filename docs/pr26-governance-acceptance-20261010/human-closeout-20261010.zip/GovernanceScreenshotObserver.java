import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;

/** Read-only current authenticated session and visible panel observation; sends no commands. */
public final class GovernanceScreenshotObserver {
 static final Path ROOT=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix/governance");
 static final Path PROFILE=Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-joinbattle-g5-20261009/minecraft");
 static Object field(Object value,String name)throws Exception{Class<?> c=value.getClass();while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(value);}catch(NoSuchFieldException ignored){c=c.getSuperclass();}}throw new NoSuchFieldException(name);}
 static void require(boolean ok,String reason){if(!ok)throw new IllegalStateException(reason);}
 static void log(String line)throws Exception{Files.write(ROOT.resolve("screenshot-session-proof-20261010.txt"),(new Date().toInstant()+" "+line+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 public static void main(String[] args)throws Exception{VirtualMachine vm=VirtualMachine.attach(args[0]);try{vm.loadAgent(args[1]);}finally{vm.detach();}}
 public static void agentmain(String ignored,Instrumentation instrumentation)throws Exception{
  Class<?> found=null;for(Class<?> c:instrumentation.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))found=c;require(found!=null,"No Minecraft client");
  final Object client=found.getMethod("func_71410_x").invoke(null);final ClassLoader loader=found.getClassLoader();
  require(((File)field(client,"field_71412_D")).toPath().toRealPath().equals(PROFILE.toRealPath()),"Wrong profile");
  Class<?> addon=loader.loadClass("kome.common.KOMEAddon");java.net.URL url=addon.getProtectionDomain().getCodeSource().getLocation();if("jar".equals(url.getProtocol()))url=((java.net.JarURLConnection)url.openConnection()).getJarFileURL();final Path jar=Paths.get(url.toURI());StringBuilder digest=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(jar)))digest.append(String.format("%02x",b&255));final String hash=digest.toString();require(hash.equals("ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823"),"Wrong loaded candidate");
  Object proxy=addon.getField("proxy").get(null);final CountDownLatch done=new CountDownLatch(1);final Throwable[] failure={null};
  proxy.getClass().getMethod("enqueueClientTask",Runnable.class).invoke(proxy,new Runnable(){public void run(){try{
   Object player=field(client,"field_71439_g");require(player!=null&&field(client,"field_71441_e")!=null,"Client disconnected");Object uuid=player.getClass().getMethod("func_110124_au").invoke(player);require(uuid.toString().equals("a976a4b7-0614-49c0-b992-61a3a89bd773"),"Wrong identity");
   log("PASS CONNECTED identity=_Danye_ uuid="+uuid+" loadedJar="+jar+" sha256="+hash+" thread="+Thread.currentThread().getName()+" readOnly=true commandsSent=0");
   Object screen=field(client,"field_71462_r");if(screen!=null&&screen.getClass().getName().equals("kome.client.gui.KOMEGuiJoinBattle")){
    Object model=field(screen,"model"),view=model.getClass().getMethod("view").invoke(model);require(field(view,"tileId").equals("T388"),"Wrong tile");require(field(view,"reason").toString().equals("GOVERNANCE_RESTRICTED"),"Wrong reason");require(field(view,"reasonText").equals("Your current war governance status prevents Join Battle participation."),"Wrong reason text");Object join=null;for(Object button:(List<?>)field(screen,"field_146292_n"))if(((Integer)field(button,"field_146127_k"))==1)join=button;require(join!=null&&!(Boolean)field(join,"field_146124_l"),"Join enabled");
    log("PASS PANEL tile=T388 conflict="+field(view,"conflictId")+" revision="+field(view,"conflictRevision")+" reason=GOVERNANCE_RESTRICTED text="+field(view,"reasonText")+" joinEnabled=false connected=true");
   }else log("PANEL_ALREADY_CLOSED screenshot remains independent human evidence; current connection verified");
  }catch(Throwable t){failure[0]=t;try{log("FAIL "+t);}catch(Exception ignored){}}finally{done.countDown();}}});
  require(done.await(20,TimeUnit.SECONDS),"Client observation timeout");if(failure[0]!=null)throw new RuntimeException(failure[0]);
 }
}

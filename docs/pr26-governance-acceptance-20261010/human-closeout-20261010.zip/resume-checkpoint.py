from pathlib import Path
import datetime, hashlib, json, sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[3] / 'build/tile-acceptance-20261006'))
from nbt_snapshot import read_nbt
candidate = json.loads((root / 'candidate.json').read_text(encoding='utf-8'))
server = Path(candidate['server'])
world = server / candidate['world']
saved = read_nbt(world / 'data/KOME_ServerRules.dat')['data']
restricted = read_nbt(root / 'restricted.dat')
sections = ['ArmyCompanies', 'HiredUnits', 'ConflictRecords', 'PlayerGovernance', 'WarSeason']
for name in sections[1:]:
    assert saved[name] == restricted[name], name
assert len(saved['ArmyCompanies']) == len(restricted['ArmyCompanies']) == 1
original_company = restricted['ArmyCompanies'][0]
current_company = saved['ArmyCompanies'][0]
company_changes = {name: {'before': original_company.get(name), 'after': current_company.get(name)} for name in original_company.keys() | current_company.keys() if original_company.get(name) != current_company.get(name)}
assert set(company_changes) <= {'MovementAllowance'}, company_changes
assert original_company['Id'] == current_company['Id'] == 'C1'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
profile = Path(candidate['profile']) / 'minecraft'
for jar in [server / 'mods/KOME-LOTR-Addon-1.0.8.jar', profile / 'mods/KOME-LOTR-Addon-1.0.8.jar']:
    assert sha(jar) == candidate['sha256']
for name, digest in candidate['config_hashes'].items():
    assert sha(server / 'config' / name) == digest
    assert sha(profile / 'config' / name) == digest
assert json.loads((server / 'ops.json').read_text(encoding='utf-8')) == []
properties = lambda p: dict(line.split('=', 1) for line in Path(p).read_text(encoding='utf-8').splitlines() if '=' in line and not line.startswith('#'))
assert properties(server / 'server.properties') == properties(root.parent.parent / 'singleplayer/server/server.properties')
result = {
    'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'candidate_sha256': candidate['sha256'], 'protocol': candidate['protocol'],
    'identity': '_Danye_', 'uuid': candidate['uuid'], 'address': candidate['address'],
    'existing_server_process': 47508, 'server_controller': 17096,
    'frozen_server_process': 30672, 'frozen_controller': 43016,
    'live_port_observation': '127.0.0.1:51327 owned by 47508; 51326 owned by 30672; original creation times retained',
    'persisted_fixture_sections_verified_unchanged': sections[1:],
    'company_eligibility_inputs_unchanged': True,
    'automatic_company_state_changes_since_original_checkpoint': company_changes,
    'checkpoint_comparison_note': 'First exact comparison detected automatic movement allowance initialization; retained in this record. All other company fields and hired/conflict/governance/season authorities match. No fixture edits were needed.',
    'common_configs_matching_recorded_hashes': len(candidate['config_hashes']),
    'server_properties_values_unchanged': True, 'ops_empty': True,
    'baseline_evidence_reused': 'Native live-player eligibility and selected C1 returned ALLOWED before restriction on October 9; synthetic registered company, no physical-entry claim.',
    'governance_state': 'SUBMITTED revision 1 for war-00001; existing choose authority confirmed it idempotently after defeat retention',
    'expected_panel_reason': 'Your current war governance status prevents Join Battle participation.',
    'client_resume': 'Previous client exited overnight. CLI requested existing g5 instance with existing _Danye_ profile and 51327 target; no fresh connected-client observation claimed.',
    'human_governance_observation': 'PENDING',
    'disconnect_retest': 'Finished; user explicitly confirms resolved. Not repeated.',
    'multiplayer': 'DEFERRED',
    'product_source_changes': False, 'product_rebuild': False, 'fixture_recreated': False,
    'preservation': json.loads((root / 'preservation-20261010.json').read_text(encoding='utf-8')),
    'prior_record_sha256': {name: sha(root / name) for name in ['validation.json', 'evidence.zip', 'before.dat', 'eligible-baseline.dat', 'restricted.dat', 'human-observation.json']}
}
(root / 'resume-20261010.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'fixture_eligibility_inputs': 'UNCHANGED', 'automatic_company_changes_recorded': company_changes, 'candidate': candidate['sha256'], 'configs': 25, 'human_governance': 'PENDING', 'no_rebuild': True}))

from pathlib import Path
import datetime, hashlib, json, shutil, sys, zipfile

root = Path(__file__).resolve().parent
fix = root.parent
workspace = fix.parents[2]
sys.path.insert(0, str(workspace / 'build/tile-acceptance-20261006'))
from nbt_snapshot import read_nbt

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
candidate = json.loads((fix / 'candidate.json').read_text(encoding='utf-8'))
player = candidate['uuid']
world = fix / 'runtime/server' / candidate['world']
profile = Path(candidate['profile']) / 'minecraft'
expected = candidate['sha256']
assert sha(world.parent / 'mods/KOME-LOTR-Addon-1.0.8.jar') == expected
assert sha(profile / 'mods/KOME-LOTR-Addon-1.0.8.jar') == expected
assert json.loads((world.parent / 'ops.json').read_text(encoding='utf-8')) == []
properties_file = world.parent / 'server.properties'
prior_properties = fix.parent / 'singleplayer/server/server.properties'
properties = lambda p: dict(line.split('=', 1) for line in Path(p).read_text(encoding='utf-8').splitlines() if '=' in line and not line.startswith('#'))
assert sha(prior_properties) == candidate['server_properties_sha256']
assert properties(properties_file) == properties(prior_properties)
for name, digest in candidate['config_hashes'].items():
    assert sha(world.parent / 'config' / name) == digest, name
    assert sha(profile / 'config' / name) == digest, name

before = read_nbt(root / 'before.dat')
baseline = read_nbt(root / 'eligible-baseline.dat')
restricted = read_nbt(root / 'restricted.dat')
saved_file = world / 'data/KOME_ServerRules.dat'
saved = read_nbt(saved_file)['data']
assert not before['ArmyCompanies'] and not before['HiredUnits'] and not before['ConflictRecords']
assert not baseline['PlayerGovernance'] and not baseline['WarSeason']['FactionDefeats']
assert baseline['WarSeason']['Phase'] == 'WAR'
for key in ['ArmyCompanies', 'HiredUnits', 'ConflictRecords']:
    assert baseline[key] == restricted[key], key
for key in ['ArmyCompanies', 'HiredUnits', 'ConflictRecords', 'PlayerGovernance', 'WarSeason']:
    assert saved[key] == restricted[key], key
records = [row for row in restricted['PlayerGovernance'] if row['Player'] == player]
assert len(records) == 1 and records[0]['State'] == 'SUBMITTED'
assert restricted['ArmyCompanies'][0]['Id'] == 'C1'
assert restricted['HiredUnits'][0]['UnitClass'] == 'CAMPAIGN'
server = (root / 'server-proof.txt').read_text(encoding='utf-8')
client = (root / 'client-production-proof.txt').read_text(encoding='utf-8')
assert 'BASELINE PASS reason=ALLOWED selectedCompany=ALLOWED' in server
assert 'RESTRICTED PASS reason=GOVERNANCE_RESTRICTED' in server
assert 'PASS governance-restricted matching authenticated production command' in client
assert client.count('GUI tile=T388 reason=GOVERNANCE_RESTRICTED') == 2

shutil.copy2(saved_file, root / 'saved-world-authority.dat')
shutil.copy2(world / 'LOTR/players' / (player + '.dat'), root / 'lotr-player-saved.dat')
shutil.copy2(fix / 'runtime/console.log', root / 'server-console-at-staging.log')
shutil.copy2(world.parent / 'logs/latest.log', root / 'server-latest-at-staging.log')
shutil.copy2(fix / 'candidate.json', root / 'candidate.json')
shutil.copy2(fix / 'runtime/process.json', root / 'process.json')
shutil.copy2(world.parent / 'ops.json', root / 'ops.json')
shutil.copy2(world.parent / 'server.properties', root / 'server.properties')
shutil.copy2(world.parent / 'config/kome.cfg', root / 'kome.cfg')

human_file = root / 'human-observation.json'
if not human_file.exists():
    human_file.write_text(json.dumps({
        'status': 'PENDING', 'test': 'joinbattle-governance-restriction-T388',
        'candidate_sha256': expected, 'authenticated_player': '_Danye_', 'uuid': player,
        'address': candidate['address'], 'command': '/kome joinbattle T388',
        'expected': 'T388 panel: Your current war governance status prevents Join Battle participation.; Select / Join Battle disabled; remains connected',
        'reply': None, 'limits': 'One authenticated non-operator. Multiplayer deferred. Native checks are recorded separately.'
    }, indent=2) + '\n', encoding='utf-8')

entries = sorted(p for p in root.iterdir() if p.is_file() and p.suffix in ['.java', '.py', '.dat', '.txt', '.log', '.cfg', '.properties', '.json'] and p.name != 'validation.json')
archive = root / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in entries:
        z.write(p, p.name)
result = {
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'candidate': candidate, 'published_head_at_start': '4925e931f6909bf24a6cbdbd44290bfa51c1df67',
    'scope': 'One-account Join Battle defeated/submitted governance denial; no battle entry or physical deployment',
    'fixture': {'tile': 'T388', 'dimension': 100, 'player_position': [78017.5, 200, 66242.5],
        'prior_native_pledge': 'DALE', 'fixture_native_pledge': 'GONDOR',
        'company': 'C1', 'company_owner': 'f107f077-470a-49ee-93c2-692b51fbcfb1',
        'company_member': '1f52a2fa-07d0-49d7-82d4-c3b8755ec36d', 'campaign_combat_members': 1,
        'member_setup': 'Synthetic canonical registered record, no spawned physical NPC or population debit',
        'coherence': 'UNKNOWN_PHYSICAL_STATE; permitted by current eligibility authority',
        'conflict': 'CF1', 'revision': 4, 'state': 'ORDINARY', 'faction_participants': ['gondor', 'mordor'],
        'war': 'war-00001', 'phase': 'WAR', 'season': 1},
    'native_baseline': {'result': 'PASS', 'production_service_live_player': 'ALLOWED',
        'selected_company_revalidation': 'ALLOWED', 'fresh_player_action_token_issued': True},
    'restriction': {'canonical_defeat_publication': 'KOMEWorldData.publishFactionDefeat(gondor) with explicit acceptance fixture audit',
        'governance_authority': 'KOMEGovernanceService.choose(data, live player UUID, war-00001, SUBMITTED, empty host, monotonic timestamp)',
        'choose_allowed': True, 'automatic_defeat_retention': 'SUBMITTED revision 1 created for known Gondor members',
        'choose_idempotent': True, 'record': records[0], 'company_member_conflict_unchanged': True},
    'native_restricted': {'result': 'PASS', 'production_service_live_player': 'GOVERNANCE_RESTRICTED',
        'selected_company_revalidation': 'GOVERNANCE_RESTRICTED', 'action_token_empty': True,
        'packet_reason_text': 'Your current war governance status prevents Join Battle participation.'},
    'connected_client_automation': {'result': 'PASS', 'loaded_client_server_sha256_match': expected,
        'identity': '_Danye_', 'uuid': player, 'actions': ['public command', 'panel observation', 'actual Refresh request/response', 'panel observation', 'close to world'],
        'observed': 'T388 GOVERNANCE_RESTRICTED exact reason text; disabled Join; remains connected', 'human': False},
    'save_evidence': {'server_save_all': 'Saving... / Saved the world at 15:15:35 local',
        'saved_authority_sections_equal_restricted_snapshot': ['ArmyCompanies', 'HiredUnits', 'ConflictRecords', 'PlayerGovernance', 'WarSeason'],
        'cold_restart_tested': False},
    'preservation': json.loads((root / 'preservation.json').read_text(encoding='utf-8')),
    'configuration_reverified': {'common_cfg_files': len(candidate['config_hashes']), 'server_properties_values_unchanged': True,
        'server_properties_current_sha256': sha(properties_file), 'server_properties_prelaunch_sha256': candidate['server_properties_sha256'],
        'server_properties_byte_difference': 'Minecraft rewrote timestamp/order on original g5 startup at 14:41:36; exact key/value comparison to retained prelaunch file has zero differences. No configuration changes for this test.', 'ops_empty': True},
    'harness_failures_preserved': [
        'V1 reflection ambiguity before mutation',
        'V2 package-private classification lookup after disposable pledge/war setup; original snapshot retained',
        'V3 noncanonical fixture company ID rejected by CommitmentInput; fixture corrected using existing canonical allocator without replacing world',
        'V2 initial compile lacked target directory; no agent ran; corrected before attach'],
    'product_source_changes': False, 'product_rebuild': False, 'runtime_replacement': False,
    'human_observation': json.loads(human_file.read_text(encoding='utf-8')),
    'limits': ['No validated legal arrival, physical deployment, capital capture, complete defeat predicate or population debit is claimed.',
        'This is native production authority and one real authenticated connection with synthetic setup; human observation remains separate.',
        'No multiplayer, lower-spec performance, merge or deployment. Frozen port 51326 unchanged.'],
    'evidence_sha256': {p.name: sha(p) for p in entries}, 'archive_sha256': sha(archive)
}
(root / 'validation.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'native_baseline': 'ALLOWED', 'native_restricted': 'GOVERNANCE_RESTRICTED', 'connected_client_automation': 'PASS',
    'saved_fixture_sections_verified': True, 'human': result['human_observation']['status'], 'archive_sha256': result['archive_sha256']}))

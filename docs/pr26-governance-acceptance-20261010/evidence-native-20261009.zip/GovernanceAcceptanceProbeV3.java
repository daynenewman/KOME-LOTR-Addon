import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;

/** Disposable governance fixture only; never changes product classes or operator permissions. */
public final class GovernanceAcceptanceProbeV3 {
 static final Path FIX=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix");
 static final Path ROOT=FIX.resolve("governance");
 static final UUID PLAYER=UUID.fromString("a976a4b7-0614-49c0-b992-61a3a89bd773");
 static final UUID OWNER=UUID.fromString("f107f077-470a-49ee-93c2-692b51fbcfb1");
 static final UUID MEMBER=UUID.fromString("1f52a2fa-07d0-49d7-82d4-c3b8755ec36d");
 static final String COMPANY="C-GOV-ACCEPTANCE",TEXT="Your current war governance status prevents Join Battle participation.";
 static ClassLoader loader;
 static Class<?> type(String name)throws Exception{return loader.loadClass(name.contains(".")?name:"kome.common.data."+name);}
 static Object field(Object value,String name)throws Exception{Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(value instanceof Class?null:value);}catch(NoSuchFieldException absent){c=c.getSuperclass();}}throw new NoSuchFieldException(name);}
 static void set(Object value,String name,Object next)throws Exception{value.getClass().getField(name).set(value,next);}
 static Class<?> box(Class<?> c){if(c==int.class)return Integer.class;if(c==long.class)return Long.class;if(c==boolean.class)return Boolean.class;if(c==double.class)return Double.class;if(c==float.class)return Float.class;return c;}
 static Object call(Object value,String name,Object... args)throws Exception{
  Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();Method match=null;
  for(Method m:c.getMethods())if(m.getName().equals(name)&&m.getParameterTypes().length==args.length){boolean ok=true;Class<?>[] ps=m.getParameterTypes();for(int i=0;i<args.length;i++)if(args[i]!=null&&!box(ps[i]).isInstance(args[i]))ok=false;if(ok){if(match!=null && !Arrays.equals(match.getParameterTypes(),m.getParameterTypes()))throw new IllegalStateException("Ambiguous "+name);if(match==null || (match.isBridge() && !m.isBridge()))match=m;}}
  if(match==null)throw new NoSuchMethodException(c.getName()+"."+name);return match.invoke(value instanceof Class?null:value,args);
 }
 static Object en(String name,String constant)throws Exception{for(Object e:type(name).getEnumConstants())if(e.toString().equals(constant))return e;throw new IllegalArgumentException(constant);}
 static void require(boolean condition,String message){if(!condition)throw new IllegalStateException(message);}
 static String hash(Path path)throws Exception{StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)))s.append(String.format("%02x",b&255));return s.toString();}
 static void log(String text)throws Exception{Files.write(ROOT.resolve("server-proof.txt"),(new Date().toInstant()+" "+text+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 static Map map(Object data,String name)throws Exception{return (Map)field(data,name);}
 static Object tag(Object data)throws Exception{Object t=type("net.minecraft.nbt.NBTTagCompound").newInstance();call(data,"func_76187_b",t);return t;}
 static void snapshot(Object data,String name)throws Exception{
  Object tag=tag(data);Method writer=null;for(Method m:type("net.minecraft.nbt.CompressedStreamTools").getMethods())if(Modifier.isStatic(m.getModifiers())&&m.getReturnType()==void.class&&Arrays.equals(m.getParameterTypes(),new Class<?>[]{tag.getClass(),OutputStream.class}))writer=m;
  require(writer!=null,"Compressed writer unavailable");Path p=ROOT.resolve(name+".dat");require(!Files.exists(p),"Snapshot already exists: "+p);try(OutputStream stream=Files.newOutputStream(p)){writer.invoke(null,tag,stream);}log("SNAPSHOT "+name+" sha256="+hash(p));
 }
 static Object expected(Object record)throws Exception{return call(type("KOMEConflictContracts$ExpectedConflict"),"at",call(record,"getConflictId"),call(record,"getRevision"));}
 static Object context(long now,String reason)throws Exception{return type("KOMEConflictContracts$Context").getConstructor(long.class,String.class,String.class).newInstance(now,"ACCEPTANCE_FIXTURE",reason);}
 static Object ok(Object result)throws Exception{require((Boolean)call(result,"isSuccess"),"Conflict fixture denied: "+field(result,"code")+" "+field(result,"reason"));return field(result,"record");}
 public static void main(String[] args)throws Exception{VirtualMachine vm=VirtualMachine.attach(args[0]);try{vm.loadAgent(args[1],args.length>2?args[2]:"inspect");}finally{vm.detach();}}
 public static void agentmain(final String mode,Instrumentation instrumentation)throws Exception{
  require(Paths.get(System.getProperty("user.dir")).toRealPath().equals(FIX.resolve("runtime/server").toRealPath()),"Wrong server; refuses mutation");
  Class<?> bridge=null;for(Class<?> c:instrumentation.getAllLoadedClasses())if(c.getName().equals("AcceptanceTaskBridge"))bridge=c;
  require(bridge!=null,"Missing server-thread bridge");loader=bridge.getClassLoader();final CountDownLatch done=new CountDownLatch(1);final Throwable[] failure={null};
  bridge.getMethod("enqueueServerTask",Runnable.class).invoke(null,new Runnable(){public void run(){try{runServer(mode);}catch(Throwable t){failure[0]=t;try{log("FAIL mode="+mode+" "+t);}catch(Exception ignored){}t.printStackTrace();}finally{done.countDown();}}});
  require(done.await(25,TimeUnit.SECONDS),"Server-thread timeout");if(failure[0]!=null)throw new RuntimeException(failure[0]);
 }
 static void runServer(String mode)throws Exception{
  Class<?> addon=type("kome.common.KOMEAddon");java.net.URL url=addon.getProtectionDomain().getCodeSource().getLocation();if("jar".equals(url.getProtocol()))url=((java.net.JarURLConnection)url.openConnection()).getJarFileURL();Path jar=Paths.get(url.toURI());
  require(hash(jar).equals("ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823"),"Wrong loaded candidate");
  Object server=call(type("net.minecraft.server.MinecraftServer"),"func_71276_C"),manager=call(server,"func_71203_ab"),player=call(manager,"func_152612_a","_Danye_");
  require(player!=null,"_Danye_ not connected");require(PLAYER.equals(call(player,"func_110124_au")),"Wrong authenticated identity");require(!(Boolean)call(player,"func_70003_b",2,"kome"),"Player has elevated permission");
  Object world=call(type("net.minecraftforge.common.DimensionManager"),"getWorld",100);require(world!=null,"Middle-earth unloaded");Object data=call(type("KOMEWorldData"),"get",world),service=call(data,"getConflictService"),season=field(data,"warSeason");
  Object nativeData=call(type("lotr.common.LOTRLevelData"),"getData",player),pledge=call(nativeData,"getPledgeFaction");
  Object record=call(service,"get","T388");log("LIVE mode="+mode+" jar="+jar+" sha256="+hash(jar)+" player="+PLAYER+" nonOperator=true pledge="+pledge+" companies="+map(data,"armyCompanies").size()+" hired="+map(data,"hiredUnits").size()+" wars="+map(data,"wars").size()+" conflict="+(record==null?"absent":call(record,"getConflictId"))+" season="+field(season,"phase")+" thread="+Thread.currentThread().getName());
  Object join=field(type("KOMEJoinBattleService"),"INSTANCE");Object projection=call(join,"evaluate",data,player,"T388");log("CURRENT reason="+field(projection,"reason")+" rows="+((List)field(projection,"eligibleCompanies")).size());
  if("inspect".equals(mode))return;
  if("verify".equals(mode)){require("GOVERNANCE_RESTRICTED".equals(field(projection,"reason").toString()),"Restriction not retained");require(record!=null&&(Boolean)call(record,"isActive"),"Conflict not active");require(map(data,"armyCompanies").containsKey(COMPANY),"Fixture company lost");log("PASS RETAINED native restricted active battle; nonOperator=true");return;}
  require("stage".equals(mode),"Unknown mode");require(record==null,"Preserve existing conflict; staging requires absent T388");require(map(data,"wars").isEmpty() || (map(data,"wars").size()==1 && "Governance acceptance".equals(field(map(data,"wars").values().iterator().next(),"displayName"))),"Preserve unrelated war");require(!(Boolean)call(season,"isFactionDefeated","gondor"),"Already defeated; cannot establish baseline");require(!map(data,"armyCompanies").containsKey(COMPANY)&&!map(data,"hiredUnits").containsKey(MEMBER),"Fixture collision");
  require(call(field(type("KOMEJoinBattleEgressService"),"INSTANCE"),"findOpen",data,PLAYER)==null,"Player has deployment receipt");if(!Files.exists(ROOT.resolve("before.dat")))snapshot(data,"before");else log("RESUME prior snapshot retained; V2 failed at package-private classification after war creation");
  Path playerFile=FIX.resolve("runtime/server/pr26-integration-disposable/playerdata/"+PLAYER+".dat");if(Files.exists(playerFile) && !Files.exists(ROOT.resolve("player-before.dat")))Files.copy(playerFile,ROOT.resolve("player-before.dat"));
  if(pledge==null||!"GONDOR".equals(pledge.toString())){Object gondor=field(type("lotr.common.fac.LOTRFaction"),"GONDOR");call(nativeData,"setPledgeFaction",gondor);log("SETUP_NATIVE_PLEDGE prior="+pledge+" next=GONDOR disposable fixture only");}
  map(data,"lastKnownPlayerFactions").put(PLAYER,"gondor");map(data,"lastKnownPlayerFactions").put(OWNER,"gondor");
  long now=System.currentTimeMillis();Object creation=call(type("KOMEWarService"),"createWarResult",data,"gondor","mordor","Governance acceptance","ACCEPTANCE_FIXTURE",now);Object war=field(creation,"war");require(war!=null,"War creation denied: "+field(creation,"reason"));require((Boolean)call(season,"isPopulationPayoutEnabled"),"Not War or Finale");String warId=(String)field(war,"id");
  Object company=type("KOMEArmyCompany").newInstance();set(company,"id",COMPANY);set(company,"owner",OWNER);set(company,"ownerName","Acceptance fixture owner");set(company,"faction","gondor");set(company,"nativeFaction","gondor");set(company,"name","Governance acceptance company");set(company,"currentTile","T388");set(company,"sourceTileId","T388");set(company,"totalPopulation",20);set(company,"groundPopulation",20);set(company,"createdAtMillis",now);set(company,"updatedAtMillis",now);((List)field(company,"units")).add(MEMBER);
  Object member=type("KOMEHiredUnitRecord").newInstance();set(member,"entity",MEMBER);set(member,"owner",OWNER);set(member,"controller",OWNER);set(member,"companyId",COMPANY);set(member,"companyName",field(company,"name"));set(member,"currentTile","T388");set(member,"sourceTileId","T388");set(member,"sourceFaction","gondor");set(member,"unitFaction","gondor");set(member,"populationOwningFaction","gondor");set(member,"cost",20);set(member,"baseCost",20);set(member,"populationSpent",20);Method classify=type("KOMEHiredUnitRecord").getDeclaredMethod("assignPersistedUnitClass",type("KOMEHiredUnitClass"));classify.setAccessible(true);classify.invoke(member,en("KOMEHiredUnitClass","CAMPAIGN"));
  map(data,"armyCompanies").put(COMPANY,company);map(data,"hiredUnits").put(MEMBER,member);
  record=ok(call(service,"start","T388",en("KOMEConflictRecord$State","ORDINARY"),call(type("KOMEConflictContracts$ExpectedConflict"),"absent"),Collections.emptyList(),context(++now,"Explicit active governance fixture; no capture or arrival acceptance")));
  for(String faction:new String[]{"gondor","mordor"})record=ok(call(service,"beginFactionParticipation","T388",expected(record),faction,context(++now,"Governance fixture faction participation")));
  Object input=type("KOMEConflictContracts$CommitmentInput").getConstructor(String.class,type("KOMEHiredUnitClass"),type("KOMEConflictRecord$EntryOrigin"),String.class).newInstance(COMPANY,en("KOMEHiredUnitClass","CAMPAIGN"),en("KOMEConflictRecord$EntryOrigin","LEGAL_ARRIVAL"),"M-GOV-FIXTURE");
  record=ok(call(service,"commit","T388",expected(record),input,context(++now,"Explicit registered-company fixture, not validated physical/legal arrival")));call(data,"func_76185_a");
  projection=call(join,"evaluate",data,player,"T388");require((Boolean)call(projection,"isAllowed"),"Baseline not allowed: "+field(projection,"reason"));List rows=(List)field(projection,"eligibleCompanies");require(rows.size()==1&&COMPANY.equals(field(rows.get(0),"companyId")),"Unexpected eligible companies");Object selection=call(join,"validateSelectedCompany",data,player,"T388",expected(record),COMPANY);require((Boolean)call(selection,"isAllowed"),"Baseline selected company denied: "+field(selection,"reason"));
  Object packet=call(type("kome.common.network.KOMEPacketJoinBattleViewResponse"),"forPlayer",projection,PLAYER,data);require(!((String)field(packet,"actionToken")).isEmpty(),"Baseline action token absent");log("BASELINE PASS reason=ALLOWED selectedCompany=ALLOWED war="+warId+" conflict="+call(record,"getConflictId")+" revision="+call(record,"getRevision")+" company="+COMPANY+" fixtureOwner="+OWNER+" member="+MEMBER+" campaignCombatMembers="+field(rows.get(0),"campaignCombatMemberCount")+" coherence="+field(rows.get(0),"coherenceStatus")+" tokenIssued=true; registered synthetic member, no physical deployment claim");snapshot(data,"eligible-baseline");
  Object companyBefore=call(company,"writeToNBT"),memberBefore=call(member,"writeToNBT"),conflictBefore=record;
  Object audit=type("KOMEAuditEntry").getConstructor(long.class,String.class,String.class,String.class,String.class,String.class,String.class).newInstance(++now,"GOVERNANCE_FIXTURE","CANONICAL_DEFEAT","ACCEPTANCE_FIXTURE","gondor","Governance panel restriction acceptance only","Explicit defeat setup; no capital capture or geography mutation");
  Method publish=type("KOMEWorldData").getDeclaredMethod("publishFactionDefeat",String.class,long.class,type("KOMEAuditEntry"));publish.setAccessible(true);require((Boolean)publish.invoke(data,"gondor",now,audit),"Defeat not published");Object prior=call(type("KOMEGovernanceService"),"record",data,PLAYER,warId);
  Object decision=call(type("KOMEGovernanceService"),"choose",data,PLAYER,warId,en("KOMEPlayerGovernance$State","SUBMITTED"),"",++now);require((Boolean)field(decision,"allowed"),"Governance choose denied: "+field(decision,"reason"));Object governance=call(type("KOMEGovernanceService"),"record",data,PLAYER,warId);require("SUBMITTED".equals(field(governance,"state").toString()),"Not submitted");
  projection=call(join,"evaluate",data,player,"T388");require("GOVERNANCE_RESTRICTED".equals(field(projection,"reason").toString()),"Wrong denial: "+field(projection,"reason"));selection=call(join,"validateSelectedCompany",data,player,"T388",expected(record),COMPANY);require("GOVERNANCE_RESTRICTED".equals(field(selection,"reason").toString()),"Selected company wrong denial");packet=call(type("kome.common.network.KOMEPacketJoinBattleViewResponse"),"forPlayer",projection,PLAYER,data);require(TEXT.equals(field(packet,"reasonText")),"Wrong panel text");require(((String)field(packet,"actionToken")).isEmpty(),"Restricted view issues token");
  require(companyBefore.equals(call(company,"writeToNBT"))&&memberBefore.equals(call(member,"writeToNBT")),"Governance modified company/member");require(conflictBefore==call(service,"get","T388"),"Governance modified immutable conflict");require(!(Boolean)call(player,"func_70003_b",2,"kome"),"Player elevated after fixture");
  log("RESTRICTED PASS reason=GOVERNANCE_RESTRICTED selectedCompany=GOVERNANCE_RESTRICTED text="+TEXT+" war="+warId+" governance=SUBMITTED revision="+field(governance,"revision")+" chooseAllowed=true automaticDefeatRetention="+(prior!=null)+" chooseIdempotent="+(prior==governance)+" tokenEmpty=true companyMemberAndConflictNBTUnchanged=true nonOperator=true");call(data,"func_76185_a");snapshot(data,"restricted");
  Files.write(ROOT.resolve("ready.txt"),("READY g5 127.0.0.1:51327; native baseline ALLOWED before canonical defeat and KOMEGovernanceService.choose SUBMITTED; expected panel text: "+TEXT+"\n").getBytes(StandardCharsets.UTF_8));
 }
}



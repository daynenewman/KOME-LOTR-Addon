import csv,hashlib,io,json,re,subprocess,collections
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent; R=ROOT/'implementation'; D=R/'docs/kom59-mountain-separation-20261010'
F=R/'src/test/resources/kome/tile/mountain-separation-approved'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=list(csv.DictReader((F/'recommended-cell-manifest.csv').open(newline='')))
mask=R/'src/main/resources/assets/kome/map/reset_conquest_tile_ids.png'
a=np.array(Image.open(F/'before-mask.png')); b=np.array(Image.open(mask))
retired=set(re.findall(r'RETIRED_TILE_IDS.add\("(T[0-9]+)"\)',(R/'src/main/java/kome/common/data/KOMEConquestTileDefaults.java').read_text()))
# Retired authority is populated by Collections.addAll in this checkout.
if not retired:
    text=(R/'src/main/java/kome/common/data/KOMEConquestTileDefaults.java').read_text()
    retired=set(re.findall(r'"(T[0-9]+)"',text[text.index('static {'):]))
mapping={}
for line in (mask.parent/'reset_conquest_tile_ids.txt').read_text().splitlines():
    if '=' not in line:continue
    rgb,t=line.split('=');rgb=list(map(int,rgb.split(',')));mapping[(rgb[0]<<16)|(rgb[1]<<8)|rgb[2]]=0 if t in retired else int(t[1:])
def grid(rgba):
    rgb=(rgba[:,:,0].astype('int32')<<16)|(rgba[:,:,1].astype('int32')<<8)|rgba[:,:,2]
    lut=np.zeros(max(mapping)+1,dtype='uint16')
    for color,t in mapping.items():lut[color]=t
    out=np.zeros(rgb.shape,dtype='uint16'); ok=(rgba[:,:,3]>24)&(rgb<len(lut));out[ok]=lut[rgb[ok]];return out
ga,gb=grid(a),grid(b)
assert len(set(np.unique(ga))-{0})==621 and set(np.unique(ga))==set(np.unique(gb))
changed={(int(x),int(y)) for y,x in np.argwhere(np.any(a!=b,axis=2))}
assert changed=={(int(r['mask_x']),int(r['mask_y'])) for r in rows}
def contact(g,pair):
    first,second=[int(t[1:]) for t in pair.split('-')];out=[0,0]
    for dx,dy in [(1,0),(0,1),(1,1),(-1,1)]:
        if dx>=0:left=g[:4000-dy,:3200-dx];right=g[dy:,dx:]
        else:left=g[:4000-dy,1:];right=g[dy:,:3199]
        n=int(np.count_nonzero(((left==first)&(right==second))|((left==second)&(right==first))))
        out[0 if dx==0 or dy==0 else 1]+=n
    return out
pairs=list(dict.fromkeys(r['pair'] for r in rows))
contacts={p:{'before':contact(ga,p),'after':contact(gb,p)} for p in pairs}
assert all(v['after']==[0,0] for v in contacts.values())
components={}
for tid in sorted({t for p in pairs for t in p.split('-')}):
    num=int(tid[1:]);todo=set(np.flatnonzero(gb==num).tolist());counts=[]
    while todo:
        seed=todo.pop();q=collections.deque([seed]);n=0
        while q:
            pos=q.popleft();n+=1
            for near in [pos-1,pos+1,pos-3200,pos+3200]:
                if 0<=near<12800000 and (near//3200==pos//3200 or near%3200==pos%3200) and near in todo:
                    todo.remove(near);q.append(near)
        counts.append(n)
    components[tid]=counts;assert len(counts)==1
corridors={}
for r in csv.DictReader((F/'protected-corridors.csv').open(newline='')):
    c={'before':contact(ga,r['pair']),'after':contact(gb,r['pair']),'edge':r['type']}
    assert c['before']==[int(r['before_shared_edges']),int(r['before_corners'])]
    assert c['after']==[int(r['after_shared_edges']),int(r['after_corners'])]
    corridors[r['pair']]=c
refs=0
points=R/'src/main/resources/assets/kome/config/kome_tile_gameplay_points.csv'
for r in csv.DictReader(io.StringIO('\n'.join(l for l in points.read_text().splitlines() if not l.startswith('#')))):
    for x,z in [(r['routeX'],r['routeZ']),(r['arrivalX'],r['arrivalZ'])]:
        cell=(int(np.floor(float(x)/128+810)),int(np.floor(float(z)/128+730)))
        assert cell not in changed;refs+=1
unchanged={}
for line in (F/'unchanged-resources.tsv').read_text().splitlines():
    name,h=line.split('\t');assert digest(R/'src/main/resources'/name)==h;unchanged[name]=h
changes=subprocess.check_output(['git','diff','--name-only','--','src/main/resources'],cwd=R,text=True).splitlines()
assert set(changes)=={'src/main/resources/assets/kome/map/reset_conquest_tile_ids.png','src/main/resources/assets/kome/map/tile_exclusions.tsv'}
assert not subprocess.check_output(['git','diff','--name-only','--','src/test/resources/kome/tile/gameplay-baseline'],cwd=R).strip()
result={'exact_rgba_changes':45,'outside_manifest_changes':0,'active_ids_before':621,'active_ids_after':621,
 'contact_counts_shared_edges_and_diagonal_corners':contacts,'affected_tile_components':components,'protected_corridors':corridors,
 'configured_route_and_arrival_points_checked':refs,'points_on_removed_cells':0,'unchanged_resource_count':len(unchanged),
 'unchanged_resources_sha256':unchanged,'historical_golden_git_diff_empty':True,'exclusion_index_bytes':25600000,
 'evidence_level':'Offline decoded production resources; production loader/graph validation is recorded separately; no world/entity observation'}
(D/'geometry-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
visuals=D/'visuals';visuals.mkdir(exist_ok=True)
for pair in pairs:
    data=subprocess.check_output(['git','show','4475f90:docs/kom59-geography-decisions-20261010/visuals/'+pair+'.png'],cwd=R)
    (visuals/(pair+'.png')).write_bytes(data)
print(json.dumps({k:v for k,v in result.items() if k not in ['unchanged_resources_sha256','protected_corridors']},indent=2))

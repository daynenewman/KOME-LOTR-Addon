import hashlib,json,shutil,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;R=ROOT/'implementation';D=R/'docs/kom59-mountain-separation-20261010'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
doc=json.loads((D/'documentation-checks.json').read_text())
p=D/'validation.json';v=json.loads(p.read_text(encoding='utf-8'));v['documentation_checks']=doc
v['retained_setup_failures_and_corrections'].append({'stage':'evidence assembly','cause':'Windows default cp1252 decoding corrupted UTF-8 punctuation; staging also exposed CRLF evidence and a blank EOF in the whitespace checker','correction':'Regenerated the README from its UTF-8 source, used explicit UTF-8 reads and removed the blank EOF. Exact captured JSON bytes retain cr-at-eol whitespace handling; source and authored Markdown checks stay strict.'})
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
readme=D/'README.md';s=readme.read_text(encoding='utf-8')
s=s.replace('All 45 cells become RGBA','The whole-raster resource audit retains the preexisting unrelated T423 two-component territory; this batch does not repair or alter it.\n\nAll 45 cells become RGBA')
s=s.replace('## World-adoption gates','Documentation: routing checker **PASS** (25 documents, 748 links, 920 symbols, 48 selectors), all introduced package/guide links and five embedded crops resolve, and whitespace checks pass. The expanded check retained one inherited broken historical image link in KOME_TILE_WORLD_RESOLUTION.md (land-before-after.png); it already exists unchanged in base dev. See [documentation checks and retained limitation](documentation-checks.json).\n\n## World-adoption gates')
readme.write_text(s.rstrip()+'\n',encoding='utf-8',newline='\n')
audit=D/'whole-raster-audit';audit.mkdir(exist_ok=True)
for name in ['audit.md','tiles.csv','components.csv']:
    shutil.copy2(R/'build/reports/tile-resource-audit'/name,audit/name)
(audit/'.gitattributes').write_text('*.csv -text whitespace=cr-at-eol\n*.md -text whitespace=cr-at-eol\n',encoding='utf-8')
with zipfile.ZipFile(D/'validation-evidence.zip','a',zipfile.ZIP_DEFLATED) as z:
    for name in ['routing-check.log','whitespace-check.log']:z.write(ROOT/'validation'/name,'documentation/'+name)
    z.write(ROOT/'check_docs.py','provenance/check_docs.py')
    z.write(D/'documentation-checks.json','documentation/checks.json')
    for name in ['audit.md','tiles.csv','components.csv']:z.write(audit/name,'whole-raster-audit/'+name)
p=D/'evidence-checksums.json';j=json.loads(p.read_text(encoding='utf-8'))
for name in j:j[name]=sha(D/name)
j['documentation-checks.json']=sha(D/'documentation-checks.json')
p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
exclude=R/'.git/info/exclude';text=exclude.read_text();exclude.write_text(text+'\n# Preserve generated validation log archives locally.\n/logs/\n',encoding='utf-8')
print('Sealed validation evidence, retained initial failures and historical link limitation; generated logs preserved locally.')

import datetime,hashlib,json,shutil,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parent;R=ROOT/'implementation';D=R/'docs/kom59-mountain-separation-20261010'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def results(p,allow_failure=False):
    counts={k:0 for k in ['tests','failures','errors','skipped']};skips=[];failures=[];suites=[]
    for file in sorted(p.glob('TEST-*.xml')):
        suite=ET.parse(file).getroot();n={k:int(suite.attrib.get(k,0)) for k in counts}
        for k in counts:counts[k]+=n[k]
        suites.append({'suite':suite.attrib['name'],**n})
        for case in suite.findall('testcase'):
            if case.find('skipped') is not None:skips.append(case.attrib['classname']+'.'+case.attrib['name'])
            for f in case.findall('failure'):failures.append({'case':case.attrib['name'],'message':f.attrib.get('message')})
    counts['passed']=counts['tests']-counts['skipped']-counts['failures']-counts['errors']
    assert counts['tests']>0
    if not allow_failure:assert counts['failures']==counts['errors']==0
    return {'counts':counts,'skipped_cases':skips,'failures':failures,'suites':suites}
focused=results(ROOT/'validation/focused-1-results');clean=results(R/'build/test-results/test')
corrected=results(ROOT/'validation/focused-correction-results')
failed_clean=results(ROOT/'validation/clean-test-build-failed-results',True)
assert focused['counts']['tests']==99
assert 'BUILD SUCCESSFUL' in (ROOT/'validation/full-test-build.log').read_text()
candidate=json.loads((ROOT/'candidate.json').read_text())
packages=[]
for jar in sorted((R/'build/libs').glob('*.jar')):
    if '-sources' in jar.name:continue
    with zipfile.ZipFile(jar) as z:
        checked={}
        for name in ['assets/kome/map/reset_conquest_tile_ids.png','assets/kome/map/tile_exclusions.tsv']+[l.split('\t')[0] for l in (D/'unchanged-resources.tsv').read_text().splitlines()]:
            data=z.read(name);assert data==(R/'src/main/resources'/name).read_bytes();checked[name]=hashlib.sha256(data).hexdigest()
        assert checked['assets/kome/map/reset_conquest_tile_ids.png']==candidate['after_png_sha256']
        assert checked['assets/kome/map/tile_exclusions.tsv']==candidate['exclusions_sha256']
        assert not any(n.startswith('lotr/') and n.endswith('.class') for n in z.namelist())
        major=int.from_bytes(z.read('kome/common/data/KOMETileWorldResolver.class')[6:8],'big');assert major==52
        packages.append({'name':jar.name,'sha256':sha(jar),'bytes':jar.stat().st_size,'class_major':major,'resources':checked,'bundled_lotr_base_classes':False})
assert len(packages)==2
(D/'packaged-resources.json').write_text(json.dumps({'jars':packages,'checked_resources_per_jar':24,'runtime_installations':0},indent=2)+'\n')
before=json.loads((ROOT/'protected-before.json').read_text());after=json.loads((ROOT/'protected-after-build.json').read_text());assert before==after
pres={'existing_worktrees':len(before['worktrees']),'heads_branches_statuses_equal':True,'local_refs_and_stash_equal':True,
 'published_review_checkout_equal':True,'original_package_hashes_equal':True,'protected_runtime_files':len(before['runtimes']),
 'runtime_files_equal':True,'runtime_process_ids_and_start_times_equal':True,'listeners':before['listeners'],
 'baseline_sha256':sha(ROOT/'protected-before.json'),'after_build_sha256':sha(ROOT/'protected-after-build.json'),
 'world_writes':0,'runtime_commands':0,'runtime_stops_or_restarts':0,'deployment':False,'migration':False}
(D/'preservation.json').write_text(json.dumps(pres,indent=2)+'\n')
failures=[
 {'stage':'authority extraction','cause':'Approved review commit was not present in the local clone initially','correction':'Fetched exact approved commit without pruning; extracted immutable files and verified authority SHA.'},
 {'stage':'mask edit preparation','cause':'First helper assumed comma CSV columns; canonical mapping uses RGB=TileID','correction':'Read mapping format and corrected parser before any raster mutation. Failed attempt retained in archive.'},
 {'stage':'validation coordination','cause':'Initial validator waited because preserved 51328 controller holds the existing leaf mutex continuously','correction':'Stopped only this task waiting validator before Gradle launch. Verified all three retained controller identities/logs and serialized offline checks on Local\\KOME-Heavy-Validation-686a-Offline under that reservation chain. No runtime stopped or reservation released.'},
 {'stage':'cross-platform resource assertions','cause':'Ordinary unchanged text resources use platform checkout line endings','correction':'Regression compares canonical Git bytes after CRLF normalization for those five text resources; byte-pinned resources and current-checkout artifact audit remain exact.'}
]
report={'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_dev':candidate['base_dev'],
 'validated_implementation_commit':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD:src'),
 'source_diff_since_validated_commit':git('diff','HEAD','--','src'),
 'geometry_provenance':candidate,'initial_focused_and_failed_clean_source_commit':'e1739d0422f4fd7ba2e58183652e90ecd76f5f4a',
 'focused':focused,'initial_clean_test_build_FAILED':failed_clean,
 'focused_assertion_corrections':corrected,'full_test_build_after_clean_attempt':clean,
 'commands':{'focused':'gradlew.bat test '+ ' '.join('--tests '+s['suite'] for s in focused['suites'])+' --offline --no-daemon --console=plain --max-workers=2',
 'initial_clean_FAILED':'gradlew.bat clean test build --offline --no-daemon --console=plain --max-workers=2',
 'focused_correction':'gradlew.bat test --tests kome.client.KOMEMountainContactBordersTest --tests kome.common.data.KOMETileResourceAuditTest --tests kome.common.data.KOMEMountainSeparationTest --offline --no-daemon --console=plain --max-workers=2',
 'full_after_correction':'gradlew.bat test build --offline --no-daemon --console=plain --max-workers=2'},
 'environment':{'gradle':'8.5','java_home':'C:/Users/dayne/.gradle/jdks/azul_systems__inc_-17-amd64-windows/zulu17.66.19-ca-fx-jdk17.0.19-win_x64',
 'target_java':8,'minecraft':'1.7.10','forge':'10.13.4.1614','gradle_max_workers':2,'gradle_heap':'1g',
 'libraries':{p.name:sha(p) for p in (R/'libs').glob('*.jar')}},
 'coordination':'Retained same-session global reservation 43016/30672 and associated child 47800/22264, retained leaf 46756/31700 verified; offline child serialized using Local\\KOME-Heavy-Validation-686a-Offline. No owner reservation released.',
 'retained_setup_failures_and_corrections':failures,
 'retained_test_failure_correction':'Initial clean run discovered 3095 tests: two historical assertions still expected touching tiles and unclassified gaps. Preserved original contact counts against immutable pre-edit mask; independent pinned 45-cell authority now controls classified status. No production code changed. Corrected focused checks and full test/build rerun passed.',
 'limits':['No new Forge launch, human check, multiplayer or hardware acceptance.','Current production-save and physical-entity impact unknown; world-adoption gate remains.','T340/T352, Harnen and T364 excluded.','No save migration, runtime commands, merge or deployment.']}
assert not report['source_diff_since_validated_commit']
(D/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
zpath=D/'validation-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for label,location in [('focused-1',ROOT/'validation/focused-1-results'),('clean-test-build-failed',ROOT/'validation/clean-test-build-failed-results'),('focused-correction',ROOT/'validation/focused-correction-results'),('full-test-build',R/'build/test-results/test')]:
        z.write(ROOT/'validation'/(label+'.log'),label+'/gradle.log')
        for f in sorted(location.glob('TEST-*.xml')):z.write(f,label+'/'+f.name)
    for name in ['apply_geometry.py','adapt_tests.py','audit_geometry.py','validate.ps1','collect_evidence.py','protected-before.json','protected-after-build.json','linear-source.json']:
        z.write(ROOT/name,'provenance/'+name)
(D/'evidence-checksums.json').write_text(json.dumps({'validation-evidence.zip':sha(zpath),'geometry-audit.json':sha(D/'geometry-audit.json'),
 'validation.json':sha(D/'validation.json'),'packaged-resources.json':sha(D/'packaged-resources.json')},indent=2)+'\n')
readme=D/'README.md';s=readme.read_text().replace('saved-reference-inventory.md','saved-reference-evidence/summary.json')
s=s.replace('## Validation and retained evidence',f"## Validation and retained evidence\n\nInitial focused: **{focused['counts']['passed']} passed**, no failures/errors/skips. The one clean attempt retained **two failed historical geometry assertions** and five skips. Corrections preserve historical rendering counts against the immutable pre-edit mask and add only the independently approved exclusion delta. Corrected focused checks: **{corrected['counts']['passed']} passed**. Full test/build resumed after that clean attempt: **{clean['counts']['tests']} discovered, {clean['counts']['passed']} passed, {clean['counts']['skipped']} skipped**, no failures/errors. Exact commands and both failed cases are retained below and in the archive. Validated source commit: **{report['validated_implementation_commit']}**; the subsequent publication commit changes documentation/evidence only. Exact publication head is recorded in the draft PR. Both development and reobfuscated production JARs passed the 24-resource readback and Java 8 class checks.")
readme.write_text(s,encoding='utf-8',newline='\n')
# Preserve captured evidence bytes and terminal whitespace without relaxing source/Markdown checks.
(D/'.gitattributes').write_text('*.csv -text whitespace=cr-at-eol\n*.json -text\n*.zip -text\n',encoding='utf-8',newline='\n')
print(json.dumps({'focused':focused['counts'],'focused_correction':corrected['counts'],'full_test_build':clean['counts'],'jars':[{k:j[k] for k in ['name','sha256','bytes']} for j in packages]},indent=2))

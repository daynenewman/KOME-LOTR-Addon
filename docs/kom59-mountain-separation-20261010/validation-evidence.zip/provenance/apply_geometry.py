import csv, hashlib, io, json, shutil, subprocess
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'implementation'
COMMIT = '4475f90d6269408a3d2f170b97276d91dcf568b9'
AUTH = 'f14472b0e865974634bc5b6e791e0ce872687f1fda6a56958ec038165a9b4b5e'
def sha(b): return hashlib.sha256(b).hexdigest()
def source(name): return subprocess.check_output(['git','show',f'{COMMIT}:docs/kom59-geography-decisions-20261010/{name}'], cwd=REPO)
DOC = REPO / 'docs/kom59-mountain-separation-20261010'
FIX = REPO / 'src/test/resources/kome/tile/mountain-separation-approved'
DOC.mkdir(parents=True, exist_ok=True)
FIX.mkdir(parents=True, exist_ok=True)
raw = source('recommended-cell-manifest.csv')
assert sha(raw) == AUTH
rows = list(csv.DictReader(io.StringIO(raw.decode())))
runs_raw = source('recommended-exclusion-manifest.csv')
runs = list(csv.DictReader(io.StringIO(runs_raw.decode())))
assert len(rows) == 45 and len(runs) == 25
expected = {'T654':2,'T420':10,'T329':4,'T355':8,'T352':2,'T356':4,'T218':15}
assert {k:sum(r['before_tile']==k for r in rows) for k in expected} == expected
cells = {(int(r['mask_x']),int(r['mask_y'])):r for r in rows}
expanded = {(x,int(r['mask_y'])):r['zone_id'] for r in runs for x in range(int(r['x_start_inclusive']),int(r['x_end_exclusive']))}
assert len(cells)==45 and expanded == {p:r['zone_id'] for p,r in cells.items()}
for name in ['recommended-cell-manifest.csv','recommended-exclusion-manifest.csv','protected-corridors.csv']:
    data=source(name)
    (DOC/name).write_bytes(data)
    (FIX/name).write_bytes(data)
for folder in (DOC,FIX): (folder/'.gitattributes').write_text('*.csv -text\n',encoding='utf-8')
mask = REPO/'src/main/resources/assets/kome/map/reset_conquest_tile_ids.png'
old = mask.read_bytes()
assert sha(old)=='ab792277f61882d415963bf5af1b8d2705458c68de80f5b3cbb9102e30d1b4a7'
(FIX/'before-mask.png').write_bytes(old)
image=Image.open(io.BytesIO(old))
assert image.mode=='RGBA' and image.size==(3200,4000)
before=np.asarray(image).copy()
mapping={}
for line in (mask.parent/'reset_conquest_tile_ids.txt').read_text().splitlines():
    if not line.strip() or line.startswith('#'): continue
    color,tile=line.split('='); mapping[tuple(int(v) for v in color.split(','))]=tile
after=before.copy()
for (x,y),r in cells.items():
    assert mapping.get(tuple(before[y,x,:3]))==r['before_tile'] and before[y,x,3]==255
    assert r['after_tile']=='GAP' and r['after_rgba']=='0,0,0,0' and r['zone_type']=='mountain'
    after[y,x]=0
Image.fromarray(after).save(mask)
new=mask.read_bytes(); newhash=sha(new)
zones=list(dict.fromkeys(r['zone_id'] for r in runs))
assert len(zones)==5
lines=['# KOM-59: exact 45-cell mountain separation approved by Dayne on 2026-10-10.',
       '# Authority: decision package 4475f90; recommended-cell-manifest.csv SHA256 '+AUTH,
       '# Other gaps remain unclassified. This metadata does not authorize strategic passage.',
       'schema=1','width=3200','height=4000','mask_sha256='+newhash]
lines += ['zone\t'+z+'\tmountain\tApproved KOM-59 narrow mountain-contact separation (2026-10-10)' for z in zones]
lines += ['run\t'+r['mask_y']+'\t'+r['x_start_inclusive']+'\t'+r['x_end_exclusive']+'\t'+r['zone_id'] for r in runs]
metadata=mask.parent/'tile_exclusions.tsv'
metadata.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
check=np.asarray(Image.open(mask))
assert {(int(x),int(y)) for y,x in np.argwhere(np.any(before!=check,axis=2))}==set(cells)
provenance={'revision':'kom59-approved-mountain-separation-20261010','base_dev':'26ba6cb7d1bbe7d4e0e4482b4f5855e15747c04d',
 'approval_commit':COMMIT,'authority_sha256':AUTH,'before_png_sha256':sha(old),'after_png_sha256':newhash,
 'exclusions_sha256':sha(metadata.read_bytes()),'changed_cells':45,'zones':5,'runs':25,'removed_by_tile':expected,
 'historical_golden_unchanged':True,'gameplay_resources_unchanged':True,
 'excluded':['T340/T352','Harnen','T364'],'world_adoption':'BLOCKED pending authoritative stopped target-save and physical-entity inventory'}
(DOC/'geometry-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
(ROOT/'candidate.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
libs=REPO/'libs'; libs.mkdir(exist_ok=True)
for name in ['LOTRMod v36.15.jar','geckolib-unofficial-1.7.10-1.0.4.jar']:
    shutil.copy2(Path('C:/Users/dayne/OneDrive/Desktop/The-Lord-of-the-Rings-main/KOME-LOTR-Addon/libs')/name,libs/name)
print(json.dumps(provenance,indent=2))

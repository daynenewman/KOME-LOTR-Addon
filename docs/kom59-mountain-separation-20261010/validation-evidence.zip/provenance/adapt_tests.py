import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
R=ROOT/'implementation'
T=R/'src/test/java/kome/common/data'
def edit(name,changes):
    p=T/name; s=p.read_text()
    for old,new in changes:
        assert old in s,(name,old)
        s=s.replace(old,new)
    p.write_text(s,encoding='utf-8',newline='\n')
edit('KOMETileExclusionsTest.java',[
 ('bundledEmptySetKeepsAllProtectedControlsUnclassified','bundledMountainSetKeepsAllProtectedControlsUnclassified'),
 ('assertEquals(0, s.exclusions.zoneCount()); assertEquals(0, s.exclusions.classifiedCells);','assertEquals(5, s.exclusions.zoneCount()); assertEquals(45, s.exclusions.classifiedCells);'),
 ('assertEquals(0, s.exclusions.cellIndexBytes());','assertEquals(25600000L, s.exclusions.cellIndexBytes());')])
edit('KOMEV2GeometryTest.java',[
 ('Approved V2 plus final 4,915-cell correction, preserving all pre-V2 territory.','Historical V2 replay plus the independently approved 45-cell mountain delta.'),
 ('"ab792277f61882d415963bf5af1b8d2705458c68de80f5b3cbb9102e30d1b4a7", hash(loader, KOMETileWorldResolver.MASK)','KOMEMountainSeparationTest.MASK_HASH, hash(loader, KOMETileWorldResolver.MASK)'),
 ('int changes = 0, dimension = KOMETileTestResources.dimension();','Map<Integer,KOMEMountainSeparationTest.Cell> removals = KOMEMountainSeparationTest.cells();\n        int changes = 0, removed = 0, dimension = KOMETileTestResources.dimension();'),
 ('if (id == null) { if (a[x] != b[x]) fail("Unapproved change at " + x + "," + y); continue; }',
  'KOMEMountainSeparationTest.Cell removal = removals.get(y * 3200 + x);\n                if (removal != null) {\n                    assertEquals(removal.before, id); assertTrue((a[x] >>> 24) <= 24); assertEquals(0, b[x]);\n                    KOMEMountainSeparationTest.assertMountain(KOMETileWorldResolver.INSTANCE.resolve(dimension, (x-810)*128, (y-730)*128), removal.zone);\n                    removed++; continue;\n                }\n                if (id == null) { if (a[x] != b[x]) fail("Unapproved change at " + x + "," + y); continue; }'),
 ('assertEquals(94015, changes);','assertEquals(93970, changes); assertEquals(45, removed); assertEquals(94015, changes + removed);')])
edit('KOMETileGeographyAcceptanceTest.java',[
 ('never a geography classification.','with only the separately approved mountain-cell classifications.'),
 ('long tiles = 0, gaps = 0;','java.util.Map<Integer,KOMEMountainSeparationTest.Cell> approved = KOMEMountainSeparationTest.cells();\n        long tiles = 0, gaps = 0, classified = 0;'),
 ('if (actual.status != (id == null ? IN_BOUNDS_GAP : RESOLVED)',
  'KOMEMountainSeparationTest.Cell cell = approved.get(y * 3200 + x);\n                if (cell != null) { assertEquals(0, argb); KOMEMountainSeparationTest.assertMountain(actual, cell.zone); classified++; continue; }\n                if (actual.status != (id == null ? IN_BOUNDS_GAP : RESOLVED)'),
 ('assertEquals(4067979L, tiles);','assertEquals(4067934L, tiles); assertEquals(45L, classified);'),
 ('(tiles + gaps)', '(tiles + gaps + classified)'),
 ('+ " classified=0 classificationsApproved=false"','+ " classified=" + classified + " mountainBatchApproved=true otherGapsUnclassified=true"')])
edit('KOMETileWorldResolverTest.java',[
 ('java.util.Random random = new java.util.Random(9917);','java.util.Map<Integer,KOMEMountainSeparationTest.Cell> approved = KOMEMountainSeparationTest.cells();\n        java.util.Random random = new java.util.Random(9917);'),
 ('assertEquals(expected == null ? IN_BOUNDS_GAP : RESOLVED, r.status);','KOMEMountainSeparationTest.Cell cell = approved.get(y * 3200 + x);\n            if (cell != null) { KOMEMountainSeparationTest.assertMountain(r, cell.zone); continue; }\n            assertEquals(expected == null ? IN_BOUNDS_GAP : RESOLVED, r.status);')])
paths=subprocess.check_output(['git','ls-files','src/main/resources/assets/kome/map','src/main/resources/assets/kome/config'],cwd=R,text=True).splitlines()
unchanged=[]
for name in paths:
    if name.endswith('/reset_conquest_tile_ids.png') or name.endswith('/tile_exclusions.tsv'):continue
    unchanged.append((name.replace('src/main/resources/',''),hashlib.sha256((R/name).read_bytes()).hexdigest()))
content=''.join(name+'\t'+h+'\n' for name,h in unchanged)
(R/'src/test/resources/kome/tile/mountain-separation-approved/unchanged-resources.tsv').write_text(content,encoding='utf-8',newline='\n')
(R/'docs/kom59-mountain-separation-20261010/unchanged-resources.tsv').write_text(content,encoding='utf-8',newline='\n')
script=(ROOT.parent/'kom59-t351-t352-20261010/validate.ps1').read_text().replace("'source'","'implementation'")
(ROOT/'validate.ps1').write_text(script,encoding='utf-8')
print('Adapted four tests; unchanged map/config resources:',len(unchanged))

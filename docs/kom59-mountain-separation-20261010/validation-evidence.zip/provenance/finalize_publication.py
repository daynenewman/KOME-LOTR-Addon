import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;D=ROOT/'implementation/docs/kom59-mountain-separation-20261010'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
doc=json.loads((D/'documentation-checks.json').read_text(encoding='utf-8'))
p=D/'validation.json';v=json.loads(p.read_text(encoding='utf-8'));v['documentation_checks']=doc
for key in ['focused','initial_clean_test_build_FAILED','focused_assertion_corrections','full_test_build_after_clean_attempt']:
    v[key].pop('suites',None)
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
zpath=D/'validation-evidence.zip'
with zipfile.ZipFile(zpath) as z:entries={n:z.read(n) for n in z.namelist()}
entries['documentation/checks.json']=(D/'documentation-checks.json').read_bytes()
entries['documentation/staged-whitespace-check.log']=(ROOT/'validation/staged-whitespace-check.log').read_bytes()
entries['provenance/check_docs.py']=(ROOT/'check_docs.py').read_bytes()
entries['provenance/seal_evidence.py']=(ROOT/'seal_evidence.py').read_bytes()
entries['provenance/finalize_publication.py']=Path(__file__).read_bytes()
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
    for n,data in entries.items():z.writestr(n,data)
p=D/'evidence-checksums.json';checks=json.loads(p.read_text(encoding='utf-8'))
for name in checks:checks[name]=sha(D/name)
for name in ['geometry-provenance.json','preservation.json','recommended-cell-manifest.csv','recommended-exclusion-manifest.csv']:
    checks[name]=sha(D/name)
for file in (D/'visuals').glob('*.png'):checks[file.relative_to(D).as_posix()]=sha(file)
p.write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
assert checks['recommended-cell-manifest.csv']=='f14472b0e865974634bc5b6e791e0ce872687f1fda6a56958ec038165a9b4b5e'
assert all(sha(D/name)==h for name,h in checks.items())
print('Evidence checksums sealed; compact report retains all results, skips, failed cases and corrections.')

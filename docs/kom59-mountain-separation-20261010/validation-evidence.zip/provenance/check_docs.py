import json,re,subprocess
from pathlib import Path
from urllib.parse import urlsplit,unquote
ROOT=Path(__file__).resolve().parent;R=ROOT/'implementation';D=R/'docs/kom59-mountain-separation-20261010'
documents=[D/'README.md',R/'docs/KOME_TILE_WORLD_RESOLUTION.md',R/'docs/tile-geography-review-20261002/README.md',R/'docs/routing/systems/geography/README.md',R/'docs/routing/systems/strategic-movement/README.md']
checked=0;inherited=[]
for f in documents:
    for name,dest in re.findall(r'!?\[([^\]]+)\]\(([^)\n]+)\)',f.read_text(encoding='utf-8-sig')):
        dest=dest.strip().strip('<>');url=urlsplit(dest)
        if url.scheme or url.netloc:continue
        target=(f.parent/unquote(url.path)).resolve() if url.path else f
        assert target.is_relative_to(R.resolve()),(str(f),dest)
        if not target.exists():
            relative=f.relative_to(R).as_posix()
            before=subprocess.run(['git','show','26ba6cb7d1bbe7d4e0e4482b4f5855e15747c04d:'+relative],cwd=R,text=True,capture_output=True)
            assert before.returncode==0 and dest in before.stdout,('Introduced broken link',str(f),dest)
            inherited.append({'document':relative,'destination':dest,'unchanged_in_base_dev':True})
            continue
        checked+=1
route=subprocess.run(['python','docs/routing/validate.py'],cwd=R,text=True,capture_output=True)
(ROOT/'validation/routing-check.log').write_text(route.stdout+route.stderr,encoding='utf-8');assert route.returncode==0,route.stdout+route.stderr
space=subprocess.run(['git','diff','--check','26ba6cb7d1bbe7d4e0e4482b4f5855e15747c04d'],cwd=R,text=True,capture_output=True)
(ROOT/'validation/whitespace-check.log').write_text(space.stdout+space.stderr,encoding='utf-8');assert space.returncode==0,space.stdout+space.stderr
result={'affected_markdown_documents':len(documents),'existing_local_links_and_embedded_images_checked':checked,
 'introduced_missing_links':0,'inherited_missing_historical_links':inherited,
 'initial_expanded_link_check':'FAILED on inherited missing land-before-after.png; failure preserved here; no introduced broken links',
 'routing_checker':'PASS','whitespace_check':'PASS','external_link_validation':False}
(D/'documentation-checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(ROOT/'documentation-final-pass.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(route.stdout);print(json.dumps(result))

from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path(__file__).resolve().parent;s=r.parent/'source';before=json.loads((r.parent/'protected-before.json').read_text(encoding='utf-8'))
def git(path,*args):
 return subprocess.check_output(['git','-c','safe.directory='+path,'-C',path,*args],text=True,encoding='utf-8').splitlines()
changed=[]
for w in before['worktrees']:
 path=w['path'];head=git(path,'rev-parse','HEAD')[0];status=git(path,'status','--porcelain=v1')
 if head!=w['head'] or status!=w['status']:changed.append({'path':path,'head':head,'status':status})
primary=before['worktrees'][0]['path'];refs=[x for x in git(primary,'for-each-ref','--format=%(objectname) %(refname)') if ' refs/codex/' not in x];stash=git(primary,'stash','list','--format=%H %s')
assert not changed,[w['path'] for w in changed]
assert refs==before['user_refs'],'User refs changed'
assert stash==before['stash'],'Stash changed'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mismatch=[p for p,v in before['frozen_runtime_files'].items() if sha(p)!=v];assert not mismatch,mismatch
with subprocess.Popen(['powershell','-NoProfile','-Command','Get-Process -Id 43016,30672 -ErrorAction Stop | Select-Object Id,StartTime | ConvertTo-Json'],stdout=subprocess.PIPE,text=True) as proc:
 data,_=proc.communicate();assert proc.returncode==0;process=json.loads(data)
result={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'worktrees_checked':len(before['worktrees']),'worktrees_unchanged':True,'user_refs_unchanged':True,'stash_unchanged':True,'frozen_file_hashes_checked':len(before['frozen_runtime_files']),'frozen_mismatches':mismatch,'frozen_processes':process}
(r/'preservation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

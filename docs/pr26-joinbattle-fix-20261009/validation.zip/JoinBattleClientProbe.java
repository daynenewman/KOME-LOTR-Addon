import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.File;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;

/** Actual authenticated production client command, packet decode and GUI initialization. */
public final class JoinBattleClientProbe {
 static final Path ROOT=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix");
 static final Path PROFILE=Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-joinbattle-g5-20261009/minecraft");
 static Object field(Object o,String name)throws Exception {
  Class<?> c=o instanceof Class?(Class<?>)o:o.getClass();
  while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(o instanceof Class?null:o);}catch(NoSuchFieldException e){c=c.getSuperclass();}}
  throw new NoSuchFieldException(name);
 }
 static String hash(Path p)throws Exception{byte[] b=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p));StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format("%02x",v&255));return s.toString();}
 static synchronized void log(String s)throws Exception {Files.write(ROOT.resolve("client-production-proof.txt"),(s+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 static void require(boolean ok,String why){if(!ok)throw new IllegalStateException(why);}
 public static void main(String[] a)throws Exception{VirtualMachine vm=VirtualMachine.attach(a[0]);try{vm.loadAgent(a[1]);}finally{vm.detach();}}
 public static void agentmain(String ignored,Instrumentation ins)throws Exception {
  Class<?> found=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))found=c;
  require(found!=null,"Client absent");final Class<?> mc=found;final ClassLoader cl=mc.getClassLoader();
  final Object client=mc.getMethod("func_71410_x").invoke(null);
  require(((File)field(client,"field_71412_D")).toPath().toRealPath().equals(PROFILE.toRealPath()),"Wrong profile; refusing commands");
  final Class<?> addon=cl.loadClass("kome.common.KOMEAddon");final Object proxy=addon.getField("proxy").get(null);
  final Method queue=proxy.getClass().getMethod("enqueueClientTask",Runnable.class);
  java.net.URL source=addon.getProtectionDomain().getCodeSource().getLocation();
  if("jar".equals(source.getProtocol()))source=((java.net.JarURLConnection)source.openConnection()).getJarFileURL();
  final Path jar=Paths.get(source.toURI());
  final String actualHash=hash(jar),expectedHash=Files.readAllLines(ROOT.resolve("expected-jar-sha256.txt"),StandardCharsets.UTF_8).get(0).trim();
  require(actualHash.equals(expectedHash),"Wrong loaded JAR; refusing commands");
  log("LOADED_JAR "+jar+" sha256="+actualHash);
  Class<?> wire=cl.loadClass("kome.common.network.KOMEPopulationWire");
  require("1.0.9-integration-g5".equals(wire.getField("VERSION").get(null)),"Not g5");
  require(!(Boolean)wire.getMethod("accepts",String.class).invoke(null,"1.0.9-integration-g4"),"Old g4 allowed");
  final Object player=field(client,"field_71439_g");require(player!=null&&field(client,"field_71441_e")!=null,"Must already be connected");
  Object uuid=player.getClass().getMethod("func_110124_au").invoke(player);
  require("a976a4b7-0614-49c0-b992-61a3a89bd773".equals(uuid.toString()),"Wrong authenticated identity");
  log("IDENTITY _Danye_ "+uuid+" protocol=g5 old_g4_rejected=true");
  Thread worker=new Thread(new Runnable(){public void run(){try{
   dispatch(queue,proxy,new Checked(){public void run()throws Exception{
    player.getClass().getMethod("func_71165_d",String.class).invoke(player,"/kome joinbattle T388");
    log("COMMAND /kome joinbattle T388 thread="+Thread.currentThread().getName());
   }});
   Thread.sleep(2500);
   dispatch(queue,proxy,new Checked(){public void run()throws Exception{
    verify(client);
    Object screen=field(client,"field_71462_r"),button=null;
    for(Object b:(List<?>)field(screen,"field_146292_n"))if(((Integer)field(b,"field_146127_k"))==2)button=b;
    require(button!=null,"Refresh absent");
    Method action=screen.getClass().getDeclaredMethod("func_146284_a",cl.loadClass("net.minecraft.client.gui.GuiButton"));action.setAccessible(true);action.invoke(screen,button);
    log("REFRESH actual GUI action sends view request");
   }});
   Thread.sleep(2500);
   dispatch(queue,proxy,new Checked(){public void run()throws Exception{verify(client);mc.getMethod("func_147108_a",cl.loadClass("net.minecraft.client.gui.GuiScreen")).invoke(client,new Object[]{null});log("PASS matching authenticated production command -> response54 -> handler -> client queue -> initialized/rendered GUI; refresh round trip; connected; close returns to game");}});
  }catch(Throwable e){try{log("FAIL "+e);e.printStackTrace();}catch(Exception f){}}}},"Join Battle production observer");worker.setDaemon(true);worker.start();
 }
 interface Checked{void run()throws Exception;}
 static void dispatch(Method queue,Object proxy,final Checked action)throws Exception{
  final CountDownLatch done=new CountDownLatch(1);final Throwable[] error={null};
  queue.invoke(proxy,new Runnable(){public void run(){try{action.run();}catch(Throwable e){error[0]=e;}finally{done.countDown();}}});
  require(done.await(15,TimeUnit.SECONDS),"Client task timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
 static void verify(Object client)throws Exception{
  require(field(client,"field_71441_e")!=null&&field(client,"field_71439_g")!=null,"Disconnected");
  Object screen=field(client,"field_71462_r");require(screen!=null&&screen.getClass().getName().equals("kome.client.gui.KOMEGuiJoinBattle"),"Join Battle GUI absent");
  Object model=field(screen,"model"),view=model.getClass().getMethod("view").invoke(model);
  require("T388".equals(view.getClass().getField("tileId").get(view)),"Wrong tile");
  require("NO_ACTIVE_CONFLICT".equals(view.getClass().getField("reason").get(view).toString()),"Wrong no-conflict reason");
  Object join=null;List<?> buttons=(List<?>)field(screen,"field_146292_n");
  for(Object b:buttons)if(((Integer)field(b,"field_146127_k"))==1)join=b;
  require(join!=null&&!(Boolean)field(join,"field_146124_l"),"Join must be disabled");
  log("GUI tile=T388 reason=NO_ACTIVE_CONFLICT text="+view.getClass().getField("reasonText").get(view)+" joinEnabled=false buttons="+buttons.size()+" connected=true thread="+Thread.currentThread().getName());
 }
}

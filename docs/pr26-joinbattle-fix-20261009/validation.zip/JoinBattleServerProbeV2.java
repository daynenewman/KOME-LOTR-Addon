import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;
public final class JoinBattleServerProbeV2 {
 static final Path ROOT=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix");
 public static void main(String[] a)throws Exception{VirtualMachine vm=VirtualMachine.attach(a[0]);try{vm.loadAgent(a[1]);}finally{vm.detach();}}
 public static void agentmain(String ignored,Instrumentation ins)throws Exception{
  if(!Paths.get(System.getProperty("user.dir")).toRealPath().equals(ROOT.resolve("runtime/server").toRealPath()))throw new IllegalStateException("Wrong server");
  Class<?> b=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("AcceptanceTaskBridge"))b=c;
  if(b==null)throw new IllegalStateException("Bridge absent");final ClassLoader cl=b.getClassLoader();
  final CountDownLatch done=new CountDownLatch(1);final Throwable[] error={null};
  b.getMethod("enqueueServerTask",Runnable.class).invoke(null,new Runnable(){public void run(){try{
   Class<?> addon=cl.loadClass("kome.common.KOMEAddon");java.net.URL source=addon.getProtectionDomain().getCodeSource().getLocation(); if("jar".equals(source.getProtocol()))source=((java.net.JarURLConnection)source.openConnection()).getJarFileURL(); Path jar=Paths.get(source.toURI());
   StringBuilder hash=new StringBuilder();for(byte value:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(jar)))hash.append(String.format("%02x",value&255));
   if(!hash.toString().equals(Files.readAllLines(ROOT.resolve("expected-jar-sha256.txt"),StandardCharsets.UTF_8).get(0).trim()))throw new IllegalStateException("Wrong server loaded JAR");
   Object mod=addon.getField("instance").get(null);Class<?> side=cl.loadClass("cpw.mods.fml.relauncher.Side");
   for(Object direction:side.getEnumConstants()){
    Method check=addon.getMethod("acceptsRemoteKome",Map.class,side);
    if((Boolean)check.invoke(mod,Collections.singletonMap("kome","1.0.9-integration-g4"),direction))throw new IllegalStateException("g4 accepted");
    if(!(Boolean)check.invoke(mod,Collections.singletonMap("kome","1.0.9-integration-g5"),direction))throw new IllegalStateException("g5 rejected");
   }
   Object server=cl.loadClass("net.minecraft.server.MinecraftServer").getMethod("func_71276_C").invoke(null);
   Object manager=server.getClass().getMethod("func_71203_ab").invoke(server);
   Object player=manager.getClass().getMethod("func_152612_a",String.class).invoke(manager,"_Danye_");
   if(player==null)throw new IllegalStateException("Authenticated player absent");
   if((Boolean)player.getClass().getMethod("func_70003_b",int.class,String.class).invoke(player,2,"kome"))throw new IllegalStateException("Player has elevated permission");
   if(!(Boolean)player.getClass().getMethod("func_70003_b",int.class,String.class).invoke(player,0,"kome"))throw new IllegalStateException("Public commands unavailable");
   Files.write(ROOT.resolve("server-production-proof.txt"),("PASS actual loaded server JAR="+jar+" sha256="+hash+" g4 rejected/g5 accepted Side.CLIENT and Side.SERVER; authenticated _Danye_ online, level2 denied/level0 allowed; native server thread="+Thread.currentThread().getName()+"\n").getBytes(StandardCharsets.UTF_8));
  }catch(Throwable e){error[0]=e;e.printStackTrace();}finally{done.countDown();}}});
  if(!done.await(15,TimeUnit.SECONDS))throw new IllegalStateException("Timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
}

from pathlib import Path
import json,subprocess,os,time,ctypes
r=Path(__file__).resolve().parent;server=r/'server';java=Path('C:/Users/dayne/Documents/KOME-Validation/tile-resolution-20260918-200409-d095d7/server/java8')
proof=r.parent.parent.parent/'pr-review-20261007/reload-fix-runtime/controller-cold-repaired.log'
assert 'Acquired Local\\KOME-Heavy-Validation' in proof.read_text(encoding='utf-8')
subprocess.run(['powershell','-NoProfile','-Command','Get-Process -Id 43016,30672 -ErrorAction Stop | Out-Null'],check=True)
k=ctypes.windll.kernel32;k.CreateMutexW.restype=ctypes.c_void_p;m=k.CreateMutexW(None,False,'Local\\KOME-Heavy-Validation-686a-Child')
while k.WaitForSingleObject(ctypes.c_void_p(m),1000) not in (0,0x80):pass
print('Reserved one associated acceptance runtime under existing global controller 43016; frozen runtime unchanged',flush=True)
queue=r/'commands';queue.mkdir(exist_ok=True)
try:
 with (r/'console.log').open('w',encoding='utf-8') as log:
  p=subprocess.Popen([str(java/'bin/java.exe'),'-Xms256M','-Xmx1280M','-Djava.awt.headless=true','-jar','forge-1.7.10-10.13.4.1614-1.7.10-universal.jar','nogui'],cwd=server,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
  (r/'process.json').write_text(json.dumps({'controller':os.getpid(),'pid':p.pid,'cwd':str(server),'port':51327},indent=2)+'\n',encoding='utf-8')
  deadline=time.monotonic()+150
  while time.monotonic()<deadline:
   if p.poll() is not None:raise RuntimeError('Acceptance process exited before readiness')
   if 'Done (' in (r/'console.log').read_text(encoding='utf-8',errors='replace'):break
   time.sleep(.5)
  else:raise RuntimeError('Acceptance startup timeout')
  print('READY first-account acceptance at 127.0.0.1:51327; no manual test pass claimed',flush=True)
  while p.poll() is None:
   for command in sorted(queue.glob('*.pending')):
    for line in command.read_text(encoding='utf-8').splitlines():
     if line.strip():p.stdin.write(line+'\n');p.stdin.flush()
    command.rename(command.with_suffix('.sent'))
   time.sleep(.25)
  (r/'exit.json').write_text(json.dumps({'exit_code':p.returncode})+'\n',encoding='utf-8')
finally:
 k.ReleaseMutex(ctypes.c_void_p(m));k.CloseHandle(ctypes.c_void_p(m))

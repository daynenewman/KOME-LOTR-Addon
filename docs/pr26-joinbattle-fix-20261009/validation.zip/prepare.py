from pathlib import Path
import json,hashlib,shutil,uuid,datetime,re,sys
r=Path(__file__).resolve().parent;s=r.parent/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
failed=r.parent/'singleplayer';stage=Path('C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-integrated-f154-20261009')
old=stage.parent/'kome-tile-acceptance-pr26-20261006'
observed={'reported_by':'human','reported_actions':'On KOME PR26 Integrated f154 at 127.0.0.1:51327, /kome joinbattle T388 caused fatal network error and disconnect','result':'FAIL','first_relevant_exception':'14:26:54 DecoderException caused by NullPointerException: Undefined message for discriminator 54 in channel kome','client_log_lines':'fml-client-latest.log:4376-4405','actual_connected_profile':str(old),'actual_client_sha256':sha(old/'minecraft/mods/KOME-LOTR-Addon-1.0.8.jar'),'intended_staged_profile':str(stage),'intended_staged_client_sha256':sha(stage/'minecraft/mods/KOME-LOTR-Addon-1.0.8.jar'),'failed_server_sha256':sha(failed/'server/mods/KOME-LOTR-Addon-1.0.8.jar'),'identity':'_Danye_','uuid':'a976a4b7-0614-49c0-b992-61a3a89bd773','server_head':'1dbd46cd60b4a341c23bc8b33ddddf43915b757b','loaded_client_evidence':'Actual old-profile FML startup loads old JAR, joins 51327 14:26:50, fails decoding 54 at 14:26:54. Intended integrated profile has no launch logs and retained Oct7 lastLaunchTime. No client JVM remained when inspected.','cause':'Join Battle appended packet IDs 53-58 while retaining old g4 handshake identity; older g4 client was accepted but has no discriminator 54.','server_limits':'Configured JAR hash, native startup path and g4 handshake log agree; server was saved/stopped before agent code-source inspection.','ops':json.loads((failed/'server/ops.json').read_text(encoding='utf-8')),'logs':{p.name:sha(p) for p in r.glob('failed-*.log')},'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(r/'failure.json').write_text(json.dumps(observed,indent=2)+'\n',encoding='utf-8')
if '--record-only' in sys.argv:
 print('Recorded human FAIL and exact first decoder exception with actual old-client/server identities')
 raise SystemExit(0)
jar=s/'build/libs/KOME-LOTR-Addon-1.0.8.jar';jarhash=sha(jar)
assert jarhash!='263e8ff420b0e84c81f9b802a58b7d46182dee4158bfa41c60afc213b9e43eb0'
runtime=r/'runtime';assert not runtime.exists(),'Preserve previously staged runtime'
runtime.mkdir();shutil.copytree(failed/'server',runtime/'server')
shutil.copy2(jar,runtime/'server/mods'/jar.name)
profile=stage.parent/'kome-pr26-joinbattle-g5-20261009';assert not profile.exists(),'Preserve previously staged profile'
shutil.copytree(stage,profile)
shutil.copy2(jar,profile/'minecraft/mods'/jar.name)
cfg=(profile/'instance.cfg').read_text(encoding='utf-8')
cfg=re.sub(r'^name=.*$', 'name=KOME PR26 Join Battle g5',cfg,flags=re.M)
cfg=re.sub(r'^uuid=.*$', 'uuid='+uuid.uuid4().hex,cfg,flags=re.M)
cfg=re.sub(r'^lastLaunchTime=.*$', 'lastLaunchTime=0',cfg,flags=re.M)
cfg=re.sub(r'^lastTimePlayed=.*$', 'lastTimePlayed=0',cfg,flags=re.M)
cfg=re.sub(r'^totalTimePlayed=.*$', 'totalTimePlayed=0',cfg,flags=re.M)
(profile/'instance.cfg').write_text(cfg,encoding='utf-8')
controller=(failed/'controller.py').read_text(encoding='utf-8')
start=controller.index('  a=subprocess.run(');end=controller.index("  print('READY",start)
controller=controller[:start]+controller[end:]
controller=controller.replace("proof=r.parent.parent/'pr-review-20261007", "proof=r.parent.parent.parent/'pr-review-20261007")
(runtime/'controller.py').write_text(controller,encoding='utf-8')
assert json.loads((runtime/'server/ops.json').read_text(encoding='utf-8'))==[]
clientcfg=profile/'minecraft/config';servercfg=runtime/'server/config'
shared={str(p.relative_to(clientcfg)):sha(p) for p in clientcfg.rglob('*') if p.is_file() and (servercfg/p.relative_to(clientcfg)).is_file()}
assert all(sha(servercfg/name)==v for name,v in shared.items())
(r/'expected-jar-sha256.txt').write_text(jarhash+'\n',encoding='utf-8')
candidate={'source_parent':'1dbd46cd60b4a341c23bc8b33ddddf43915b757b','protocol':'1.0.9-integration-g5','sha256':jarhash,'profile':str(profile),'display_name':'KOME PR26 Join Battle g5','server':str(runtime/'server'),'address':'127.0.0.1:51327','world':'pr26-integration-disposable','world_source':'Copied failed integrated world after orderly exit 0; original world preserved','identity':'_Danye_','uuid':observed['uuid'],'ops_empty':True,'config_hashes':shared,'server_properties_sha256':sha(runtime/'server/server.properties'),'minecraft':'1.7.10','forge':'10.13.4.1614','java':'8u482','client_heap_mib':1536,'server_heap_mib':1280,'limits':'Native production checks pending; no human/multiplayer pass inferred'}
(r/'candidate.json').write_text(json.dumps(candidate,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'ready_to_launch':str(profile),'jar_sha256':jarhash,'shared_configs':len(shared),'ops_empty':True}))

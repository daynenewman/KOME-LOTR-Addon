from pathlib import Path
import json,subprocess,hashlib,datetime
root=Path(__file__).resolve().parent
before=json.loads((root.parent.parent/'protected-before.json').read_text())
def git(path,*args):return subprocess.check_output(['git','-c','safe.directory='+path,'-C',path,*args],text=True).splitlines()
primary=before['worktrees'][0]['path']
current=[x for x in git(primary,'for-each-ref','--format=%(objectname) %(refname)') if ' refs/codex/' not in x]
old={s.split(' ',1)[1]:s.split(' ',1)[0] for s in before['user_refs']}
new={s.split(' ',1)[1]:s.split(' ',1)[0] for s in current}
diff={k:{'before':old.get(k),'now':new.get(k)} for k in sorted(set(old)|set(new)) if old.get(k)!=new.get(k)}
worktrees=[]
for w in before['worktrees']:
 path=w['path'];head=git(path,'rev-parse','HEAD')[0];status=git(path,'status','--porcelain=v1')
 if head!=w['head'] or status!=w['status']:worktrees.append(dict(path=path,head=head,status=status,before=w))
stash=git(primary,'stash','list','--format=%H %s')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mismatch=[p for p,h in before['frozen_runtime_files'].items() if sha(p)!=h]
assert not worktrees,worktrees
assert stash==before['stash']
assert not mismatch,mismatch
cmd=['powershell','-NoProfile','-Command','Get-Process -Id 43016,30672 -ErrorAction Stop | Select-Object Id,StartTime | ConvertTo-Json']
process=json.loads(subprocess.check_output(cmd,text=True))
result=dict(checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),worktrees_checked=len(before['worktrees']),worktrees_unchanged=True,stash_unchanged=True,frozen_file_hashes_checked=len(before['frozen_runtime_files']),frozen_mismatches=mismatch,frozen_processes=process,user_refs_unchanged=not diff,user_ref_deltas=diff,interpretation='Original baseline comparison explicitly preserves any concurrent external ref delta. This task only fetched/edited the independent source clone; no shared user ref write or rollback was performed.')
(root/'preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

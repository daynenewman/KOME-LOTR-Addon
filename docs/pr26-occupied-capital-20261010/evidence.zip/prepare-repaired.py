from pathlib import Path
import datetime,hashlib,json,re,shutil,uuid,zipfile
root=Path(__file__).resolve().parent
old=root.parent
source=old.parent/'source'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
jar=source/'build/libs/KOME-LOTR-Addon-1.0.8.jar'
candidate=json.loads((old/'candidate.json').read_text())
assert json.loads((old/'runtime/exit.json').read_text())['exit_code']==0
assert not (root/'runtime').exists(),'Retain all previous runtimes'
assert sha(jar)!=candidate['sha256'],'Repair JAR was not built'
assert sha(old/'runtime/server/mods'/jar.name)==candidate['sha256']
shutil.copytree(old/'runtime/server',root/'runtime/server')
shutil.copy2(jar,root/'runtime/server/mods'/jar.name)
controller=(old/'runtime/controller.py').read_text()
controller=controller.replace("r.parent.parent.parent/'pr-review-20261007", "r.parent.parent.parent.parent/'pr-review-20261007")
(root/'runtime/controller.py').write_text(controller)
old_profile=Path(candidate['profile'])
new_profile=old_profile.parent/'kome-pr26-occupied-capital-20261010'
assert not new_profile.exists(),'Retain all previous client profiles'
shutil.copytree(old_profile,new_profile)
shutil.copy2(jar,new_profile/'minecraft/mods'/jar.name)
cfg=(new_profile/'instance.cfg').read_text()
cfg=re.sub(r'^name=.*$','name=KOME PR26 Occupied Capital Repair',cfg,flags=re.M)
cfg=re.sub(r'^uuid=.*$','uuid='+uuid.uuid4().hex,cfg,flags=re.M)
for key in ['lastLaunchTime','lastTimePlayed','totalTimePlayed']:
 cfg=re.sub(r'^'+key+r'=.*$',key+'=0',cfg,flags=re.M)
(new_profile/'instance.cfg').write_text(cfg)
assert all(sha(root/'runtime/server/config'/n)==v and sha(new_profile/'minecraft/config'/n)==v for n,v in candidate['config_hashes'].items())
new=dict(candidate,sha256=sha(jar),profile=str(new_profile),display_name='KOME PR26 Occupied Capital Repair',server=str(root/'runtime/server'),source_parent='4925e931f6909bf24a6cbdbd44290bfa51c1df67',world_source='Byte copy of orderly-saved g5 world; retained governance and original four survivor UUIDs; original runtime/profile preserved',recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),server_properties_sha256=sha(root/'runtime/server/server.properties'))
for key in ['human_retest','native_production_verified','process']:
 new.pop(key,None)
new['limits']='New reset-locator repair candidate; production/human checks pending. Protocol remains g5; networking classes unchanged. No multiplayer pass.'
(root/'candidate.json').write_text(json.dumps(new,indent=2)+'\n')
(root/'repaired-candidate-sha256.txt').write_text(new['sha256']+'\n')
with zipfile.ZipFile(old/'runtime/server/mods'/jar.name) as z:
 previous={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.class')}
with zipfile.ZipFile(jar) as z:
 current={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.class')}
changed=[n for n in sorted(set(previous)|set(current)) if previous.get(n)!=current.get(n)]
assert changed==['kome/common/data/KOMESeasonResetDeployment.class'],changed
(root/'class-reuse.json').write_text(json.dumps({'previous_jar':candidate['sha256'],'repaired_jar':new['sha256'],'changed_classes':changed,'all_other_class_hashes_identical':True,'preserved_governance_pass':'Same Join Battle/governance/UI/packet classes; retained authority fixture separately verified','production_class_hashes':current},indent=2)+'\n')
print(json.dumps({'candidate':new['sha256'],'changed_classes':changed,'profile':str(new_profile),'common_configs':len(new['config_hashes'])}))

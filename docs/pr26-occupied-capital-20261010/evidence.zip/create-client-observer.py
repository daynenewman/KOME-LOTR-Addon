from pathlib import Path
root=Path(__file__).resolve().parent
base=(root/'OccupiedCapitalProbeV6.java').read_text()
prefix=base[:base.index(' static Object readTag(')]
prefix=prefix.replace('OccupiedCapitalProbeV6','OccupiedCapitalClientObserver').replace('ROOT.resolve("server-proof.txt")','ROOT.resolve("client-proof.txt")')
body=r'''
 public static void main(String[] args)throws Exception{VirtualMachine v=VirtualMachine.attach(args[0]);try{v.loadAgent(args[1],args.length>2?args[2]:"before-human");}finally{v.detach();}}
 public static void agentmain(final String phase,Instrumentation ins)throws Exception{
  Class<?> mc=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))mc=c;require(mc!=null,"Not a client");loader=mc.getClassLoader();final Object client=call(mc,"func_71410_x");
  require(((File)field(client,"field_71412_D")).toPath().toRealPath().equals(Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-occupied-capital-20261010/minecraft").toRealPath()),"Wrong repaired profile");
  java.net.URL url=type("kome.common.KOMEAddon").getProtectionDomain().getCodeSource().getLocation();if("jar".equals(url.getProtocol()))url=((java.net.JarURLConnection)url.openConnection()).getJarFileURL();final String loadedHash=hash(Paths.get(url.toURI()));require(loadedHash.equals(new String(Files.readAllBytes(ROOT.resolve("repaired-candidate-sha256.txt")),StandardCharsets.UTF_8).trim()),"Wrong loaded client JAR");
  final Properties ids=new Properties();try(InputStream in=Files.newInputStream(ROOT.resolve("fixture.properties"))){ids.load(in);}Object proxy=field(type("kome.common.KOMEAddon"),"proxy");CountDownLatch done=new CountDownLatch(1);Throwable[] error={null};call(proxy,"enqueueClientTask",new Runnable(){public void run(){try{
   Object player=field(client,"field_71439_g"),world=field(client,"field_71441_e");require(player!=null&&world!=null&&PLAYER.equals(call(player,"func_110124_au")),"Authenticated connection missing");
   for(int i=1;i<=2;i++){Object rider=null,mount=null;int rc=0,mc=0;for(Object e:(List)field(world,"field_72996_f")){String id=call(e,"func_110124_au").toString();if(id.equals(ids.getProperty("rider"+i))){rider=e;rc++;}if(id.equals(ids.getProperty("mount"+i))){mount=e;mc++;}}require(rc==1&&mc==1,"Client UUID counts wrong "+rc+"/"+mc);require(field(rider,"field_70154_o")==mount&&field(mount,"field_70153_n")==rider,"Client attachment broken");require(Float.parseFloat(ids.getProperty("riderHP"+i))==(Float)call(rider,"func_110143_aJ")&&Float.parseFloat(ids.getProperty("mountHP"+i))==(Float)call(mount,"func_110143_aJ"),"Client partial HP differs");log("PASS "+phase+" CLIENT company="+ids.getProperty("company"+i)+" rider="+ids.getProperty("rider"+i)+" mount="+ids.getProperty("mount"+i)+" uuidCounts=1/1 mounted=true partialHP="+call(rider,"func_110143_aJ")+"/"+call(mount,"func_110143_aJ")+" named="+call(rider,"func_94057_bL"));}
   log("PASS "+phase+" CONNECTED actualClientSHA256="+loadedHash+" identity="+PLAYER+" renderThread="+Thread.currentThread().getName()+" screen="+(field(client,"field_71462_r")==null?"world":field(client,"field_71462_r").getClass().getName())+" readOnly=true humanVisibilityPending=true");
  }catch(Throwable t){error[0]=t;try{log("FAIL "+t);}catch(Exception ignored){}}finally{done.countDown();}}});require(done.await(20,TimeUnit.SECONDS),"Client observer timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
}
'''
import sys
version=sys.argv[1] if len(sys.argv)>1 else ''
if version:
 body=body.replace('ROOT.resolve("fixture.properties")','ROOT.resolve("entity-network-ids.properties")')
 body=body.replace('String id=call(e,"func_110124_au").toString();if(id.equals(ids.getProperty("rider"+i)))', 'String id=call(e,"func_145782_y").toString();if(id.equals(ids.getProperty("networkRider"+i)))').replace('if(id.equals(ids.getProperty("mount"+i)))','if(id.equals(ids.getProperty("networkMount"+i)))')
 body=body.replace('" uuidCounts=1/1 mounted=true partialHP="', '" serverOriginalUUIDsCorrelatedByNetworkIds="+ids.getProperty("networkRider"+i)+"/"+ids.getProperty("networkMount"+i)+" clientEntityCounts=1/1 clientGeneratedHorseUUID="+call(mount,"func_110124_au")+" mounted=true partialHP="')
cls='OccupiedCapitalClientObserver'+version
(root/(cls+'.java')).write_text((prefix+body).replace('OccupiedCapitalClientObserver',cls))
(root/('client-manifest'+version+'.txt')).write_text('Manifest-Version: 1.0\nAgent-Class: '+cls+'\n\n')

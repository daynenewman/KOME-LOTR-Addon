import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;
public class CloseG5ClientV2 {
 static Object f(Object o,String n)throws Exception{for(Class<?> c=o.getClass();c!=null;c=c.getSuperclass())try{Field x=c.getDeclaredField(n);x.setAccessible(true);return x.get(o);}catch(NoSuchFieldException ignored){}throw new NoSuchFieldException(n);}
 public static void main(String[] a)throws Exception{VirtualMachine v=VirtualMachine.attach(a[0]);try{v.loadAgent(a[1]);}finally{v.detach();}}
 public static void agentmain(String unused,Instrumentation i)throws Exception{
  Class<?> mc=null;for(Class<?> c:i.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))mc=c;if(mc==null)throw new IllegalStateException("Not a client");final Object client=mc.getMethod("func_71410_x").invoke(null);
  Path profile=((java.io.File)f(client,"field_71412_D")).toPath().toRealPath();if(!profile.equals(Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-joinbattle-g5-20261009/minecraft").toRealPath()))throw new IllegalStateException("Wrong profile");
  if(f(client,"field_71441_e")!=null)throw new IllegalStateException("Still connected");mc.getMethod("func_71400_g").invoke(client);
 }
}


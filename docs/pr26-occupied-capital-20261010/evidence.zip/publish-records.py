from pathlib import Path
import hashlib,json,datetime,shutil,subprocess,zipfile

o=Path(__file__).resolve().parent
f=o.parent; s=f.parent/'source'; g=f/'governance'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
v=json.loads((o/'validation.json').read_text())
server=Path(v['candidate']['server']); client=Path(v['candidate']['profile'])/'minecraft'
assert sha(server/'mods/KOME-LOTR-Addon-1.0.8.jar')==sha(client/'mods/KOME-LOTR-Addon-1.0.8.jar')==v['candidate']['sha256']
assert all(sha(server/'config'/n)==sha(client/'config'/n)==h for n,h in v['candidate']['config_hashes'].items())
cp=(o/'client-proof.txt').read_text(); sp=(o/'server-proof.txt').read_text()
assert all('PASS after-human-reconnect CLIENT company='+n in cp for n in ['C2','C3'])
assert '17:24:23.332Z PASS RECONNECT clear landing' in sp
human={'test':'occupied-capital-mounted-return-reconnect','status':'PASS','recorded_at_utc':now,
 'candidate_sha256':v['candidate']['sha256'],'source_parent':v['source_parent'],
 'profile':'KOME PR26 Occupied Capital Repair','address':'127.0.0.1:51327',
 'identity':'_Danye_','uuid':v['candidate']['uuid'],'non_operator_native_verified':True,
 'actions':'Esc → Disconnect; rejoin 127.0.0.1:51327; close any menu and look around T388 at X78080.5 Y200 Z66304.5.',
 'expected':'Exactly two Gondor soldiers remain mounted on two horses, at separate positions, with no extra rider or horse and no disconnect.',
 'user_reply_verbatim':'yes!', 'question_call_id':'call_a05f51a40ba646f3aa389b7bf417f6d7',
 'observation_scope':'Human confirms visibility, mounted pairs, separate positions, no visible extras and no disconnect. UUIDs, exact HP, tokens, audit counts and tracking are separate native evidence.',
 'native_after_reconnect':{'server_proof_time_utc':'2026-10-10T17:24:23.324Z','network_map_time_utc':'2026-10-10T17:27:49.689Z','client_proof_time_utc':'2026-10-10T17:28:00.223Z','client_network_ids':{'C2':[329,330],'C3':[327,328]}}}
write(o/'human-observation.json',human)
v['recorded_at_utc']=now;v['human']=human
v['candidate']['limits']='Scoped production return/retry and human reconnect PASS. Protocol remains g5; networking classes unchanged. No multiplayer pass.'
v['native_production']['status']='PASS_SCOPED_RETURN_RETRY_NATIVE_AND_HUMAN_RECONNECT'
v['native_production']['native_tracking']='After actual 12:22:48 CDT reconnect: exactly one original server entity per UUID, original attachments and HP, player in native tracker sets; refreshed IDs C2 329/330 and C3 327/328 correlate to one mounted client tree each.'
v['native_production']['pre_human_verify_label']='The 17:20:44 verify label RECONNECT is only staged verification. Actual user disconnect/rejoin is independently logged at 12:22:37/12:22:48 CDT; post-reconnect native proof is 17:24:23 UTC and client proof 17:28:00 UTC.'
v['setup_attempts'].append({'attempt':'post-reconnect observer stale IDs','result':'First post-reconnect observer used pre-reconnect entity IDs and failed 0/0. Read-only server map refreshed after entity reload; corrected observation passes. Original failed observer line retained. No product failure or repeat human check.'})
write(o/'validation.json',v)
pres=json.loads((o/'preservation.json').read_text())
assert all(k.startswith('refs/remotes/origin/') for k in pres['user_ref_deltas'])
pres['local_branch_refs_unchanged']=True
pres['interpretation']='Remote-tracking ref deltas observed against the historical baseline; refresh/prune provenance is not established. This task fetched the independent source clone. No shared local branch ref write or rollback was performed. Original worktree states, local branch refs, stash, frozen hashes and frozen process start times match.'
write(o/'preservation.json',pres)
for src,dst in [(o/'runtime/console.log','repaired-console-after-reconnect.log'),(server/'logs/latest.log','repaired-server-after-reconnect.log'),(client/'logs/latest.log','repaired-client-after-reconnect.log')]:shutil.copy2(src,o/dst)
paths=['src/main/java/kome/common/data/KOMESeasonResetDeployment.java','src/test/java/kome/common/data/KOMESeasonResetDeploymentTest.java']
write(o/'source-manifest.json',{'parent':v['source_parent'],'paths':{n:sha(s/n) for n in paths},'candidate_sha256':v['candidate']['sha256'],'production_changed_classes':['kome/common/data/KOMESeasonResetDeployment.class'],'class_reuse_manifest_sha256':sha(o/'class-reuse.json')})
(o/'repair.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=s))
write(o/'failure.json',v['failure'])
for src in (f.parent/'validation').glob('occupied-locator-*.log'):shutil.copy2(src,o/src.name)
govdest=s/'docs/pr26-governance-acceptance-20261010';govdest.mkdir(exist_ok=True)
for p in g.iterdir():
 if p.is_file():shutil.copy2(p,govdest/p.name)
gp=govdest/'README.md';gt=gp.read_text()
gt=gt.replace('This evidence is a local acceptance checkpoint. Published PR evidence and prior human failures/passes retain their original identities. No publication or broader ticket closure is inferred from this staging run.','This published checkpoint preserves the original g5 artifact identity. Prior human failures/passes and earlier pending/native records remain intact. The later [occupied-capital repair](../pr26-occupied-capital-20261010/README.md) retains the governance fixture and byte-identical governance/Join Battle classes; it does not require a repeated human governance check. No broader ticket closure is inferred.')
gp.write_text(gt,encoding='utf-8')
write(govdest/'published-manifest.json',{'recorded_at_utc':now,'source_parent':'4925e931f6909bf24a6cbdbd44290bfa51c1df67','candidate_sha256':'ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823','files':{p.name:sha(p) for p in govdest.iterdir() if p.is_file() and p.name!='published-manifest.json'}})
od=s/'docs/pr26-occupied-capital-20261010';od.mkdir(exist_ok=True)
archive=o/'evidence.zip'
files=[p for p in o.iterdir() if p.is_file() and p.name!='evidence.zip']
for folder in ['attempt1','focused-results','clean-results']:files.extend(p for p in (o/folder).rglob('*') if p.is_file())
write(o/'archive-manifest.json',{'files':{p.relative_to(o).as_posix():sha(p) for p in files if p.name!='archive-manifest.json'}})
files=[p for p in files if p.name!='archive-manifest.json']+[o/'archive-manifest.json']
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(o).as_posix())
selected=['validation.json','human-observation.json','failure.json','source-manifest.json','class-reuse.json','preservation.json','server-proof.txt','client-proof.txt','candidate.json','fixture.properties','entity-network-ids.properties','archive-manifest.json','evidence.zip']
for n in selected:shutil.copy2(o/n,od/n)
write(od/'published-manifest.json',{'recorded_at_utc':now,'archive_sha256':sha(archive),'files':{n:sha(od/n) for n in selected}})
readme=f'''# Occupied-capital production acceptance — October 10, 2026

**PASS after a demonstrated persistence repair.** One non-operator authenticated client, `_Danye_`, on **127.0.0.1:51327**. [Exact results/configuration](validation.json), [human observation](human-observation.json), [native server](server-proof.txt), [native client](client-proof.txt), [archive/hash manifest](published-manifest.json).

## Candidate and actual failure

Source parent `{v['source_parent']}` incorporates dev `{v['dev']}`. The two changed source files and their exact hashes are in [source-manifest.json](source-manifest.json); the containing publication commit pins the repaired source. Matching running production client/server JAR SHA-256 **`{v['candidate']['sha256']}`**, protocol **1.0.9-integration-g5**. Profile **KOME PR26 Occupied Capital Repair**; Java 8u482, Forge 10.13.4.1614, LOTR 36.15; 25 identical common configurations, client/server heaps 1536/1280 MiB, view distance 2, online authentication and whitelist, empty ops.

Original g5 JAR `ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823` reproduced **`IllegalStateException: Physical locator attached to an ineligible hired-unit state`** during reset checkpoint serialization. The valid origin locator still addressed T348 after the production mounted return changed the unit/company tile to T388. This prevented a durable reset save. The valid baseline, exception, earlier fixture/observer failures and failing-before regression remain in [evidence.zip](evidence.zip) and [failure.json](failure.json).

`KOMESeasonResetDeployment.apply` now clears the stale address through the existing locator authority and checkpoints that invalidation **before physical relocation**, including receipt replay. Normal live observation can subsequently verify the new address. No schema, protocol, governance, HP or ownership rule changes. [Class comparison](class-reuse.json) verifies only `KOMESeasonResetDeployment.class` differs from g5; other packaged classes are identical.

## Validation

| Check | Observed result |
|---|---|
| Focused regression failed before repair | Expected durable locator invalidation before move; old code retained the locator |
| Five affected focused suites | **53 passed**, no skips/failures/errors |
| Required clean test/build | **3,085 discovered; 3,080 passed; five skipped; zero failures/errors** |
| Real production first return | C2 occupies capital reference X78080.5/Y200/Z66304.5, T388 |
| Real production second mounted return | C3 chooses clear X78078.5/Y200/Z66302.5; first survivor remains at reference |
| Identity and health | Original four UUIDs, original mounted attachments; C2 rider/mount 3.25/7.125 HP; C3 5.5/9.25 HP |
| Durable retry | Exactly two COMPANY_RETURN audits, tokens 1:C2 and 1:C3; retry adds no audit or move; native journal readback passes |
| Actual client reconnect | User replied **“yes!”** to exactly two mounted pairs, separate positions, no extras/disconnect |
| Post-reconnect native evidence | One entity per original server UUID; original HP/attachments; both tracked for authenticated player; client entity-ID correlation refreshed after reload, one pair each |
| Retained governance | CF1/C1/SUBMITTED and governance/war/conflict/capital/ownership/reset authority sections unchanged; prior [human governance PASS](../pr26-governance-acceptance-20261010/README.md) reused with original identity |

## Fixture and evidence limits

Two direct-API Campaign survivor fixtures use a **detached reset coordinator journal** with the production native deployment/Anvil save path. Its actual atomic `checkpointResetFile` persists `reset-journal.dat`; global governance/battle/capitals/ownership/reset state is retained. This is a production mounted-return/retry check, **not a new full global season-reset acceptance pass**. Original first company already returned before the second return. The repaired JVM cold-loaded the same saved survivors before staging; no new full canonical reset cold-restart gate is claimed. Original UUIDs and coordinates are in [fixture.properties](fixture.properties).

Validation-only `LivingHealEvent` cancellation for these four UUIDs prevents LOTR's ordinary passive rider/mount regeneration from hiding exact partial HP. No production class/config change implements that control; stock passive healing is outside this check. Earlier natural-healing and observer failures are retained and separated from the actual stale-locator product defect. Vanilla horse UUIDs are not sent in Minecraft 1.7 mob spawn: native server UUIDs correlate to client entities through fresh network IDs and mounted links. A stale-ID observer failure after reconnect was corrected by refreshing that read-only map; the human check was not repeated.

Original g5 runtime/profile/world are preserved after orderly save/stop; the repair uses copies. Frozen **51326** remains untouched: 89 hashes, original process start times, 25 worktree heads/statuses, local branch refs and stash match. [Preservation](preservation.json) explicitly records remote-tracking ref changes against the historical baseline; their refresh/prune provenance is unknown and none were rolled back.

**This focused check is complete. Multiplayer remains deferred.** No lower-spec or simultaneous-player acceptance, no broader ticket closure, dev merge or shared deployment. KOM-58/59 geography decisions and unfinished owning dependencies remain explicit. The runtime and fixtures remain ready on 51327; no further human retest is needed for this repair.
'''
(od/'README.md').write_text(readme,encoding='utf-8')
check=s/'docs/pr-review-20261007/README.md';t=check.read_text()
para='\n## October 10 governance and occupied-capital closeout\n\n[Governance acceptance](../pr26-governance-acceptance-20261010/README.md) is PASS: eligible baseline before defeat/submission, existing authority denial, real non-operator command/packet/panel/Refresh and human screenshot with exact denial. Original g5 identity is retained.\n\n[Occupied-capital production acceptance](../pr26-occupied-capital-20261010/README.md) reproduced and repaired a stale physical locator that prevented reset checkpoint serialization after return. Clear/checkpoint through the existing locator authority before relocation. **53 focused passed; clean 3,085 discovered / 3,080 passed / five skipped / zero failures/errors.** Matching repaired JAR `e20756089e48d0962b486ad14fa11407cb0782ad709931b296da5e9ed24dab53`. Native two-company production return/retry preserves original UUIDs, partial HP, clear landing and once-only receipts; user reconnect PASS for exactly two mounted pairs without extras/disconnect, with independent native tracking/HP proof. This uses an isolated durable coordinator journal to retain governance; no new full global season-reset pass is inferred.\n\nFrozen 51326 and original g5 copies remain preserved. These two focused checks are complete; actual battle entry, broader campaign flows, multiplayer (deferred), hardware measurements and explicit geography decisions remain separate.\n'
t=t.replace('## Frozen human-acceptance candidate',para+'\n## Frozen human-acceptance candidate',1)
t=t.replace('The g5 no-active-battle UI/disconnect check now passes; actual battle/governance denial and changed mounted landing/reconnect remain broader single-player acceptance.','The g5 disconnect check, focused submitted-governance denial and occupied-capital mounted return/reconnect now pass with separate exact artifact evidence below. Actual battle entry and broader campaign flows remain separate acceptance.')
lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| PR #26 current-dev integration |'):lines[i]='| PR #26 current-dev integration | PASS: integrated dev f154dea; historical restart gates retained; latest locator repair 53 focused / 3,080 full passing tests; [governance](../pr26-governance-acceptance-20261010/README.md) and [occupied-capital production/human](../pr26-occupied-capital-20261010/README.md) PASS. | Draft; actual active battle entry and broader campaign flows remain. Multiplayer deferred; no merge/deployment. |'
 elif line.startswith('| PR #26 Join Battle protocol disconnect |'):lines[i]=line.replace('Actual active-battle entry/governance and wider multiplayer acceptance remain separate','Focused governance restriction now passes; actual active-battle entry and wider multiplayer acceptance remain separate')
 elif line.startswith('| KOM-28 '):lines[i]=line.replace(' | ', ' | ',1).rstrip(' |')+'; [occupied-capital locator repair/production return/retry/human reconnect PASS](../pr26-occupied-capital-20261010/README.md), with original UUIDs and exact partial HP. Isolated journal scope is explicit; no new full global reset gate. |'
 elif line.startswith('| Governance ') or line.startswith('| Governance/daily '):lines[i]=line.replace(' | ', ' | ',1)
t='\n'.join(lines)+'\n'
# Add narrow rows without treating all governance/daily or ticket acceptance as closed.
marker='| PR #26 current-dev integration |'
idx=t.index(marker)
t=t[:idx]+'| Join Battle submitted-governance restriction | [Native baseline/denial, actual client path and human screenshot PASS](../pr26-governance-acceptance-20261010/README.md); non-operator. | Focused requirement complete; physical battle entry and multiplayer remain separate. |\n| Occupied-capital mounted reset return | [Repaired production return/retry and human reconnect PASS](../pr26-occupied-capital-20261010/README.md); original UUIDs/HP and once-only receipts. | Focused requirement complete; detached journal scope retained; no new full global reset gate. |\n'+t[idx:]
check.write_text(t,encoding='utf-8')
hp=s/'docs/pr-review-20261007/human-observations.json';h=json.loads(hp.read_text())
govhuman=json.loads((g/'human-observation.json').read_text());h['observations'].extend([govhuman,human])
h['pending_test']='Focused disconnect, submitted-governance restriction and occupied-capital mounted return/reconnect PASS. Actual active battle entry and broader campaign flows remain separate; multiplayer deferred.'
h['not_inferred']=['multiplayer','representative lower-spec performance','broader governance/daily client acceptance','other Build permissions','full global season-reset acceptance on occupied-capital repair candidate']
h['current_integration_candidate_sha256']=v['candidate']['sha256'];write(hp,h)
ip=s/'docs/pr26-integration-20261009/README.md';it=ip.read_text();start=it.index('Next smallest single-player batch');end=it.index('\n\nMultiplayer',start)
it=it[:start]+'Later focused checks are complete: [g5 disconnect/no-active-battle panel](../pr26-joinbattle-fix-20261009/README.md), [eligible-baseline submitted-governance denial and human screenshot](../pr26-governance-acceptance-20261010/README.md), and [occupied-capital production return/retry and human reconnect](../pr26-occupied-capital-20261010/README.md). The last check found and repaired a stale locator before reset checkpoint serialization; latest clean gate is 3,085 discovered / 3,080 passed / five skipped. Historical integration counts and artifact identities above remain unchanged. No repeat of completed human checks is needed.'+it[end:];ip.write_text(it,encoding='utf-8')
jp=s/'docs/pr26-joinbattle-fix-20261009/README.md';jt=jp.read_text();jt+='\n## Later scoped acceptance\n\n[Submitted-governance restriction](../pr26-governance-acceptance-20261010/README.md) passed native baseline/authority and human screenshot on this exact g5 artifact. The subsequent [occupied-capital repair](../pr26-occupied-capital-20261010/README.md) changes only reset deployment, with governance/Join Battle/network classes byte-identical. Its production return/retry and human reconnect pass separately. These checks are complete; actual physical battle entry and multiplayer remain separate.\n';jp.write_text(jt,encoding='utf-8')
for folder in [govdest,od]:
 for p in folder.glob('*.json'):json.loads(p.read_text())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,hv in json.loads((o/'archive-manifest.json').read_text())['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==hv,n
assert 'R1' in check.read_text() and 'yes!' in hp.read_text()
print(json.dumps({'human':'PASS','candidate':v['candidate']['sha256'],'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'governance_files':len(list(govdest.iterdir())),'occupied_files':len(list(od.iterdir()))},indent=2))

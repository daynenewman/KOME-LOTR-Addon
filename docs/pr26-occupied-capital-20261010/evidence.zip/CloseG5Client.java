import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;
public class CloseG5Client {
 static Object f(Object o,String n)throws Exception{for(Class<?> c=o.getClass();c!=null;c=c.getSuperclass())try{Field x=c.getDeclaredField(n);x.setAccessible(true);return x.get(o);}catch(NoSuchFieldException ignored){}throw new NoSuchFieldException(n);}
 public static void main(String[] a)throws Exception{VirtualMachine v=VirtualMachine.attach(a[0]);try{v.loadAgent(a[1]);}finally{v.detach();}}
 public static void agentmain(String unused,Instrumentation i)throws Exception{
  Class<?> mc=null;for(Class<?> c:i.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))mc=c;if(mc==null)throw new IllegalStateException("Not a client");final Object client=mc.getMethod("func_71410_x").invoke(null);
  Path profile=((java.io.File)f(client,"field_71412_D")).toPath().toRealPath();if(!profile.equals(Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-joinbattle-g5-20261009/minecraft").toRealPath()))throw new IllegalStateException("Wrong profile");
  final Class<?> type=mc;Object proxy=mc.getClassLoader().loadClass("kome.common.KOMEAddon").getField("proxy").get(null);CountDownLatch done=new CountDownLatch(1);Throwable[] error={null};proxy.getClass().getMethod("enqueueClientTask",Runnable.class).invoke(proxy,new Runnable(){public void run(){try{if(f(client,"field_71441_e")!=null)throw new IllegalStateException("Still connected; refuse closing");type.getMethod("func_71400_g").invoke(client);}catch(Throwable t){error[0]=t;}finally{done.countDown();}}});if(!done.await(15,TimeUnit.SECONDS))throw new IllegalStateException("Close timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
}

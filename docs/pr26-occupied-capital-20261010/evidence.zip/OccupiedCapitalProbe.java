import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;

/** Disposable governance fixture only; never changes product classes or operator permissions. */
public final class OccupiedCapitalProbe {
 static final Path FIX=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix");
 static final Path ROOT=FIX.resolve("occupied-capital");
 static final UUID PLAYER=UUID.fromString("a976a4b7-0614-49c0-b992-61a3a89bd773");
 static final UUID UNUSED_OWNER=UUID.fromString("f107f077-470a-49ee-93c2-692b51fbcfb1");
 static final UUID MEMBER=UUID.fromString("1f52a2fa-07d0-49d7-82d4-c3b8755ec36d");
 static final String COMPANY="C1",TEXT="Your current war governance status prevents Join Battle participation.";
 static ClassLoader loader;
 static Class<?> type(String name)throws Exception{return loader.loadClass(name.contains(".")?name:"kome.common.data."+name);}
 static Object field(Object value,String name)throws Exception{Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(value instanceof Class?null:value);}catch(NoSuchFieldException absent){c=c.getSuperclass();}}throw new NoSuchFieldException(name);}
 static void set(Object value,String name,Object next)throws Exception{value.getClass().getField(name).set(value,next);}
 static Class<?> box(Class<?> c){if(c==int.class)return Integer.class;if(c==long.class)return Long.class;if(c==boolean.class)return Boolean.class;if(c==double.class)return Double.class;if(c==float.class)return Float.class;return c;}
 static Object call(Object value,String name,Object... args)throws Exception{
  Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();Method match=null;
  for(Method m:c.getMethods())if(m.getName().equals(name)&&m.getParameterTypes().length==args.length){boolean ok=true;Class<?>[] ps=m.getParameterTypes();for(int i=0;i<args.length;i++)if(args[i]!=null&&!box(ps[i]).isInstance(args[i]))ok=false;if(ok){if(match!=null && !Arrays.equals(match.getParameterTypes(),m.getParameterTypes()))throw new IllegalStateException("Ambiguous "+name);if(match==null || (match.isBridge() && !m.isBridge()))match=m;}}
  if(match==null)throw new NoSuchMethodException(c.getName()+"."+name);return match.invoke(value instanceof Class?null:value,args);
 }
 static Object en(String name,String constant)throws Exception{for(Object e:type(name).getEnumConstants())if(e.toString().equals(constant))return e;throw new IllegalArgumentException(constant);}
 static void require(boolean condition,String message){if(!condition)throw new IllegalStateException(message);}
 static String hash(Path path)throws Exception{StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)))s.append(String.format("%02x",b&255));return s.toString();}
 static void log(String text)throws Exception{Files.write(ROOT.resolve("server-proof.txt"),(new Date().toInstant()+" "+text+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 static Map map(Object data,String name)throws Exception{return (Map)field(data,name);}
 static Object tag(Object data)throws Exception{Object t=type("net.minecraft.nbt.NBTTagCompound").newInstance();call(data,"func_76187_b",t);return t;}
 static void snapshot(Object data,String name)throws Exception{
  Object tag=tag(data);Method writer=null;for(Method m:type("net.minecraft.nbt.CompressedStreamTools").getMethods())if(Modifier.isStatic(m.getModifiers())&&m.getReturnType()==void.class&&Arrays.equals(m.getParameterTypes(),new Class<?>[]{tag.getClass(),OutputStream.class}))writer=m;
  require(writer!=null,"Compressed writer unavailable");Path p=ROOT.resolve(name+".dat");require(!Files.exists(p),"Snapshot already exists: "+p);try(OutputStream stream=Files.newOutputStream(p)){writer.invoke(null,tag,stream);}log("SNAPSHOT "+name+" sha256="+hash(p));
 }

 static Object world,global,player,server,isolated,adapter;
 static Properties ids;
 static final double DX=78080.5,DZ=66304.5,OX=48768.5,OZ=53632.5;
 static final String RECEIPT="KOMESeasonReturn";
 static Object readTag(Path path)throws Exception{
  Method reader=null;for(Method m:type("net.minecraft.nbt.CompressedStreamTools").getMethods())if(Modifier.isStatic(m.getModifiers())&&Arrays.equals(m.getParameterTypes(),new Class[]{InputStream.class})&&m.getReturnType()==type("net.minecraft.nbt.NBTTagCompound"))reader=m;
  require(reader!=null,"NBT reader missing");try(InputStream in=Files.newInputStream(path)){return reader.invoke(null,in);}
 }
 static void checkpoint(Object data)throws Exception{Method m=type("KOMEWorldData").getDeclaredMethod("checkpointResetFile",Path.class);m.setAccessible(true);m.invoke(data,ROOT.resolve("reset-journal.dat"));}
 static Object deployment()throws Exception{
  Class<?> ec=type("KOMESeasonResetDeployment$EntityCheckpoint");final Method save=type("KOMESeasonResetDeployment").getDeclaredMethod("saveEntities",type("net.minecraft.world.World"),List.class,Set.class);save.setAccessible(true);
  Object proxy=Proxy.newProxyInstance(loader,new Class[]{ec},(p,m,a)->save.invoke(null,a));
  java.util.function.Consumer<Object> intent=d->{try{checkpoint(d);}catch(Exception e){throw new RuntimeException(e);}};
  Constructor<?> ctor=type("KOMESeasonResetDeployment").getDeclaredConstructor(type("net.minecraft.world.World"),ec,java.util.function.Consumer.class);ctor.setAccessible(true);return ctor.newInstance(world,proxy,intent);
 }
 static void platform(double px,double pz)throws Exception{
  int cx=(int)Math.floor(px),cz=(int)Math.floor(pz);Object stone=field(type("net.minecraft.init.Blocks"),"field_150357_h"),air=field(type("net.minecraft.init.Blocks"),"field_150350_a"),light=field(type("net.minecraft.init.Blocks"),"field_150426_aN");
  for(int x=cx-9;x<=cx+9;x++)for(int z=cz-9;z<=cz+9;z++)for(int y=199;y<=207;y++)call(world,"func_147465_d",x,y,z,(y==199||y==207||Math.abs(x-cx)==9||Math.abs(z-cz)==9)?stone:air,0,2);
  for(int x:new int[]{cx-7,cx+7})for(int z:new int[]{cz-7,cz+7})call(world,"func_147465_d",x,206,z,light,0,2);
 }
 static UUID uuid(Object entity)throws Exception{return (UUID)call(entity,"func_110124_au");}
 static double pos(Object entity,String axis)throws Exception{return (Double)field(entity,axis.equals("x")?"field_70165_t":axis.equals("y")?"field_70163_u":"field_70161_v");}
 static void propertyFile()throws Exception{try(OutputStream out=Files.newOutputStream(ROOT.resolve("fixture.properties"))){ids.store(out,"Scoped production reset; native entities; global governance retained");}}
 static int audits(Object data,String company)throws Exception{int n=0;for(Object a:(List)field(data,"centralAudit"))if("COMPANY_RETURN".equals(field(a,"action"))&&company.equals(field(a,"target")))n++;return n;}
 static int returnAudits(Object data)throws Exception{int n=0;for(Object a:(List)field(data,"centralAudit"))if("COMPANY_RETURN".equals(field(a,"action")))n++;return n;}
 static void createSurvivor(int index)throws Exception{
  Method allocate=type("KOMEWorldData").getDeclaredMethod("nextCampaignCompanyId");allocate.setAccessible(true);String cid=(String)allocate.invoke(global);require(("C"+(index+1)).equals(cid),"Unexpected fixture company: "+cid);
  String name=index==1?"Capital Survivor":"Returning Survivor";
  Object rider=call(type("net.minecraft.entity.EntityList"),"func_75620_a","lotr.GondorSoldier",world),mount=call(type("net.minecraft.entity.EntityList"),"func_75620_a","lotr.Horse",world);require(rider!=null&&mount!=null,"Native entities unavailable");
  call(rider,"func_70012_b",OX+(index-1)*4,200D,OZ,0F,0F);call(mount,"func_70012_b",OX+(index-1)*4,200D,OZ,0F,0F);call(rider,"func_94058_c",name);call(rider,"func_110163_bv");call(mount,"func_110163_bv");call(mount,"setBelongsToNPC",true);
  Object hire=field(rider,"hiredNPCInfo");call(hire,"setHiringPlayer",player);set(hire,"isActive",true);call(hire,"setTask",field(type("lotr.common.entity.npc.LOTRHiredNPCInfo$Task"),"WARRIOR"));if(!(Boolean)call(hire,"isHalted"))call(hire,"halt");call(hire,"setGuardMode",false);
  float rh=index==1?3.25F:5.5F,mh=index==1?7.125F:9.25F;call(rider,"func_70606_j",rh);call(mount,"func_70606_j",mh);
  require((Boolean)call(world,"func_72838_d",mount),"Mount spawn rejected");require((Boolean)call(world,"func_72838_d",rider),"Rider spawn rejected");call(rider,"func_70078_a",mount);call(rider,"setRidingHorse",true);call(type("lotr.common.entity.LOTRMountFunctions"),"setNavigatorRangeFromNPC",mount,rider);
  Object company=type("KOMEArmyCompany").newInstance();set(company,"id",cid);set(company,"name",name);set(company,"owner",PLAYER);set(company,"ownerName","_Danye_");set(company,"faction","gondor");set(company,"nativeFaction","gondor");set(company,"source","campaign_recruitment");set(company,"currentTile","T348");set(company,"sourceTileId","T388");set(company,"totalPopulation",50);set(company,"mountedPopulation",50);((List)field(company,"units")).add(uuid(rider));
  Object record=type("KOMEHiredUnitRecord").newInstance();set(record,"entity",uuid(rider));set(record,"owner",PLAYER);set(record,"controller",PLAYER);set(record,"companyId",cid);set(record,"companyName",name);set(record,"currentTile","T348");set(record,"sourceTileId","T388");set(record,"mounted",true);set(record,"unitName",name);set(record,"unitEntityId","lotr.GondorSoldier");for(String key:new String[]{"cost","baseCost","populationSpent"})set(record,key,50);for(String key:new String[]{"unitFaction","populationOwningFaction","sourceFaction"})set(record,key,"gondor");set(record,"sourceType","FACTION_POPULATION_BANK");Method classify=type("KOMEHiredUnitClassification").getDeclaredMethod("assignForCampaignWorkflow",type("KOMEHiredUnitRecord"));classify.setAccessible(true);classify.invoke(null,record);set(record,"stationedEntityData",call(type("KOMEEntitySnapshots"),"snapshot",rider));call(type("KOMECampaignHealth"),"observe",record,rider);
  map(isolated,"armyCompanies").put(cid,company);map(isolated,"hiredUnits").put(uuid(rider),record);map(global,"armyCompanies").put(cid,company);map(global,"hiredUnits").put(uuid(rider),record);
  Object entry=type("KOMESeasonResetState$Return").newInstance();set(entry,"companyId",cid);set(entry,"nativeFaction","gondor");set(entry,"owner",PLAYER);set(entry,"origin","T348");set(entry,"destination","T388");set(entry,"returnRequired",true);set(entry,"capital",map(isolated,"factionCapitals").get("gondor"));((Set)field(entry,"units")).add(uuid(rider));((Map)field(field(isolated,"seasonReset"),"companies")).put(cid,entry);
  ids.setProperty("company"+index,cid);ids.setProperty("rider"+index,uuid(rider).toString());ids.setProperty("mount"+index,uuid(mount).toString());ids.setProperty("riderHP"+index,Float.toString(rh));ids.setProperty("mountHP"+index,Float.toString(mh));ids.setProperty("name"+index,name);propertyFile();log("CREATED baseline "+cid+" rider="+uuid(rider)+" mount="+uuid(mount)+" HP="+rh+"/"+mh+" source=T348 directAPIFixtureNotPaidHire=true");
 }
 static Object find(String key)throws Exception{return call(type("KOMESeasonResetDeployment"),"find",UUID.fromString(ids.getProperty(key)));}
 static void verify(String phase,boolean tracking)throws Exception{
  require((Boolean)call(field(isolated,"seasonReset"),"complete"),"Reset pending: "+call(type("KOMESeasonResetService"),"status",isolated));require(returnAudits(isolated)==2,"Return audits not once each");
  Object a=find("rider1"),b=find("rider2");require(a!=null&&b!=null,"Survivors unavailable");
  for(int i=1;i<=2;i++){
   Object rider=find("rider"+i),mount=find("mount"+i);require(rider!=null&&mount!=null&&field(rider,"field_70154_o")==mount&&field(mount,"field_70153_n")==rider,"Original mounted tree broken: "+i);
   require(Float.parseFloat(ids.getProperty("riderHP"+i))==(Float)call(rider,"func_110143_aJ")&&Float.parseFloat(ids.getProperty("mountHP"+i))==(Float)call(mount,"func_110143_aJ"),"Partial HP changed: "+i);
   String token="1:"+ids.getProperty("company"+i);for(Object e:new Object[]{rider,mount}){require(token.equals(call(call(e,"getEntityData"),"func_74779_i",RECEIPT)),"Physical receipt wrong: "+i);int count=0;for(Object loaded:(List)field(world,"field_72996_f"))if(uuid(loaded).equals(uuid(e)))count++;require(count==1,"Duplicate original UUID: "+i);}
   Object rec=map(global,"hiredUnits").get(uuid(rider));require(rec!=null&&ids.getProperty("company"+i).equals(field(rec,"companyId"))&&"T388".equals(field(rec,"currentTile")),"Canonical tracked unit missing: "+i);require((Boolean)call(type("KOMESeasonResetDeployment"),"inTile",rider,"T388"),"Wrong physical tile");
   if(tracking){Object tracker=call(world,"func_73039_n");Object hashTable=field(tracker,"field_72794_c");for(Object e:new Object[]{rider,mount}){Object tracked=call(hashTable,"func_76041_a",call(e,"func_145782_y"));require(tracked!=null,"Entity tracker missing");require(((Set)field(tracked,"field_73134_o")).contains(player),"Player not tracking original entity");}}
   log("PASS "+phase+" "+ids.getProperty("company"+i)+" rider="+uuid(rider)+" mount="+uuid(mount)+" HP="+call(rider,"func_110143_aJ")+"/"+call(mount,"func_110143_aJ")+" position="+pos(mount,"x")+","+pos(mount,"y")+","+pos(mount,"z")+" token="+token+" uuidCounts=1/1 mounted=true canonicalTile=T388 nativeTracked="+tracking);
  }
  require(pos(find("mount1"),"x")==DX&&pos(find("mount1"),"z")==DZ,"Already-returned survivor left capital reference");
  Object boxA=field(find("mount1"),"field_70121_D"),boxB=field(find("mount2"),"field_70121_D");require(!(Boolean)call(boxA,"func_72326_a",boxB),"Returned mounted trees overlap");log("PASS "+phase+" clear landing; original first survivor still at occupied reference; onceOnlyCompanyReturnAudits=2");
 }
 static void governanceUnchanged(Object before)throws Exception{
  Object after=tag(global);for(String key:new String[]{"WarSeason","Wars","PlayerGovernance","ConflictRecords","FactionCapitals","ConquestTiles","SeasonReset"})require(call(before,"func_74781_a",key).equals(call(after,"func_74781_a",key)),"Retained authority changed: "+key);
  Object baseline=readTag(ROOT.resolve("governance-company-before.dat"));require(baseline.equals(call(map(global,"armyCompanies").get("C1"),"writeToNBT")),"Governance company changed");Object projection=call(field(type("KOMEJoinBattleService"),"INSTANCE"),"evaluate",global,player,"T388");require("GOVERNANCE_RESTRICTED".equals(field(projection,"reason").toString()),"Governance PASS invalidated");log("PASS retained governance CF1/C1/SUBMITTED and exact authority sections unchanged; nonOperator=true");
 }
 static void writeObject(Object tag,String name)throws Exception{Method writer=null;for(Method m:type("net.minecraft.nbt.CompressedStreamTools").getMethods())if(Modifier.isStatic(m.getModifiers())&&m.getReturnType()==void.class&&Arrays.equals(m.getParameterTypes(),new Class[]{tag.getClass(),OutputStream.class}))writer=m;try(OutputStream out=Files.newOutputStream(ROOT.resolve(name))){writer.invoke(null,tag,out);}}
 static void run(String mode)throws Exception{
  java.net.URL url=type("kome.common.KOMEAddon").getProtectionDomain().getCodeSource().getLocation();if("jar".equals(url.getProtocol()))url=((java.net.JarURLConnection)url.openConnection()).getJarFileURL();require(hash(Paths.get(url.toURI())).equals("ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823"),"Wrong production candidate");server=call(type("net.minecraft.server.MinecraftServer"),"func_71276_C");player=call(call(server,"func_71203_ab"),"func_152612_a","_Danye_");require(player!=null&&PLAYER.equals(uuid(player)),"Authenticated player missing");require(!(Boolean)call(player,"func_70003_b",2,"kome"),"Player operator");world=call(type("net.minecraftforge.common.DimensionManager"),"getWorld",100);require(world!=null,"World unloaded");global=call(type("KOMEWorldData"),"get",world);
  log("LIVE "+mode+" productionSHA=ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823 player="+PLAYER+" nonOperator=true serverThread="+Thread.currentThread().getName());
  if(mode.equals("inspect")){Object tracker=call(world,"func_73039_n");for(Field f:tracker.getClass().getDeclaredFields())log("TRACKER_FIELD "+f.getName()+" "+f.getType());for(Object e:(List)field(world,"field_72996_f"))if(Math.abs(pos(e,"x")-DX)<15&&Math.abs(pos(e,"z")-DZ)<15)log("EXISTING target entity="+uuid(e)+" type="+e.getClass().getName());return;}
  ids=new Properties();adapter=deployment();
  if(mode.equals("stage")){
   require(!Files.exists(ROOT.resolve("fixture.properties")),"Fixture exists; no recreation");require(map(global,"armyCompanies").size()==1&&map(global,"hiredUnits").size()==1,"Unexpected existing registry");snapshot(global,"global-before");writeObject(call(map(global,"armyCompanies").get("C1"),"writeToNBT"),"governance-company-before.dat");
   for(Object e:(List)field(world,"field_72996_f"))require(Math.abs(pos(e,"x")-DX)>=12||Math.abs(pos(e,"z")-DZ)>=12,"Existing entity occupies new fixture footprint");platform(DX,DZ);platform(OX,OZ);
   isolated=type("KOMEWorldData").getConstructor(String.class).newInstance("occupied-capital-acceptance");call(isolated,"initializeIntegratedWorld",world);Object cap=type("KOMEFactionCapitalRecord").getConstructor(String.class,String.class,int.class,double.class,double.class,double.class,long.class,String.class,String.class).newInstance("gondor","T388",100,DX,200D,DZ,1L,"Scoped occupied-capital fixture","ACCEPTANCE_FIXTURE");map(isolated,"factionCapitals").put("gondor",cap);
   Object season=field(isolated,"warSeason");set(season,"phase",en("KOMEWarSeasonState$Phase","RESET"));set(season,"seasonId",1L);Object state=field(isolated,"seasonReset");set(state,"seasonId",1L);set(state,"ownershipReset",true);set(state,"prepared",true);ids.setProperty("capital",DX+",200,"+DZ);ids.setProperty("origin",OX+",200,"+OZ);ids.setProperty("candidateSHA256","ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823");
   createSurvivor(1);call(type("KOMESeasonResetService"),"process",isolated,(Long)call(world,"func_82737_E"),System.currentTimeMillis(),adapter);require((Boolean)call(state,"complete")&&returnAudits(isolated)==1,"First return incomplete");require(pos(find("mount1"),"x")==DX&&pos(find("mount1"),"z")==DZ,"First landing not capital reference");snapshot(isolated,"first-returned");log("PASS already returned C2 occupies exact capital reference with durable rider/mount receipt; no global reset");
   Object result=call(type("KOMEStrategicDeploymentResolver"),"validateStored",world,"T388",100,DX,200D,DZ);require(!(Boolean)field(result,"valid"),"Ordinary standing check should reject occupied reference");Method ref=type("KOMEStrategicDeploymentResolver").getDeclaredMethod("validateResetSearchOrigin",type("net.minecraft.world.World"),String.class,int.class,double.class,double.class,double.class);ref.setAccessible(true);require((Boolean)field(ref.invoke(null,world,"T388",100,DX,200D,DZ),"valid"),"Reset search origin still rejects survivor");
   createSurvivor(2);set(season,"resetStatus","PENDING_COMPANIES");snapshot(isolated,"second-before-return");call(type("KOMESeasonResetService"),"process",isolated,(Long)call(world,"func_82737_E"),System.currentTimeMillis(),adapter);verify("RETURN",false);snapshot(isolated,"returned");
   Object journalBefore=call(state,"write");call(type("KOMESeasonResetService"),"process",isolated,(Long)call(world,"func_82737_E"),System.currentTimeMillis(),adapter);for(Object entry:((Map)field(state,"companies")).values())require("".equals(call(adapter,"apply",isolated,entry,call(type("KOMESeasonResetService"),"token",isolated,entry))),"Completed receipt retry failed");require(journalBefore.equals(call(state,"write")),"Retry changed journal");verify("RETRY",false);checkpoint(isolated);snapshot(isolated,"retry");
   governanceUnchanged(readTag(ROOT.resolve("global-before.dat")));call(global,"func_76185_a");call(call(server,"func_71187_D"),"func_71556_a",server,"save-all");call(field(player,"field_71135_a"),"func_147364_a",DX+0D,200D,DZ+6D,180F,0F);snapshot(global,"global-staged");log("READY human reconnect at T388 capital="+DX+",200,"+DZ+" two named mounted survivors; original candidate/config retained");
  }else if(mode.equals("verify")){
   try(InputStream in=Files.newInputStream(ROOT.resolve("fixture.properties"))){ids.load(in);}isolated=type("KOMEWorldData").getConstructor(String.class).newInstance("occupied-capital-acceptance-reloaded");call(isolated,"func_76184_a",call(readTag(ROOT.resolve("reset-journal.dat")),"func_74775_l","data"));verify("RECONNECT",true);governanceUnchanged(readTag(ROOT.resolve("global-before.dat")));snapshot(global,"global-reconnect-"+System.currentTimeMillis());log("PASS native current connected reset fixture; isolated durable journal roundtrip and real entity tracking verified");
  }else throw new IllegalArgumentException(mode);
 }
 public static void main(String[] args)throws Exception{VirtualMachine vm=VirtualMachine.attach(args[0]);try{vm.loadAgent(args[1],args[2]);}finally{vm.detach();}}
 public static void agentmain(final String mode,Instrumentation ins)throws Exception{
  require(Paths.get(System.getProperty("user.dir")).toRealPath().equals(FIX.resolve("runtime/server").toRealPath()),"Wrong runtime");Class<?> bridge=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("AcceptanceTaskBridge"))bridge=c;require(bridge!=null,"Bridge unavailable");loader=bridge.getClassLoader();CountDownLatch done=new CountDownLatch(1);Throwable[] error={null};bridge.getMethod("enqueueServerTask",Runnable.class).invoke(null,new Runnable(){public void run(){try{OccupiedCapitalProbe.run(mode);}catch(Throwable t){error[0]=t;try{log("FAIL mode="+mode+" "+t);}catch(Exception ignored){}t.printStackTrace();}finally{done.countDown();}}});require(done.await(55,TimeUnit.SECONDS),"Server task timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
}

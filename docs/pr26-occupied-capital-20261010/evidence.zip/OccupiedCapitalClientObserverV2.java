import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;

/** Disposable governance fixture only; never changes product classes or operator permissions. */
public final class OccupiedCapitalClientObserverV2 {
 static final Path FIX=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/joinbattle-fix");
 static final Path ROOT=FIX.resolve("occupied-capital");
 static final UUID PLAYER=UUID.fromString("a976a4b7-0614-49c0-b992-61a3a89bd773");
 static final UUID UNUSED_OWNER=UUID.fromString("f107f077-470a-49ee-93c2-692b51fbcfb1");
 static final UUID MEMBER=UUID.fromString("1f52a2fa-07d0-49d7-82d4-c3b8755ec36d");
 static final String COMPANY="C1",TEXT="Your current war governance status prevents Join Battle participation.";
 static ClassLoader loader;
 static Class<?> type(String name)throws Exception{return loader.loadClass(name.contains(".")?name:"kome.common.data."+name);}
 static Object field(Object value,String name)throws Exception{Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(value instanceof Class?null:value);}catch(NoSuchFieldException absent){c=c.getSuperclass();}}throw new NoSuchFieldException(name);}
 static void set(Object value,String name,Object next)throws Exception{value.getClass().getField(name).set(value,next);}
 static Class<?> box(Class<?> c){if(c==int.class)return Integer.class;if(c==long.class)return Long.class;if(c==boolean.class)return Boolean.class;if(c==double.class)return Double.class;if(c==float.class)return Float.class;return c;}
 static Object call(Object value,String name,Object... args)throws Exception{
  Class<?> c=value instanceof Class?(Class<?>)value:value.getClass();Method match=null;
  for(Method m:c.getMethods())if(m.getName().equals(name)&&m.getParameterTypes().length==args.length){boolean ok=true;Class<?>[] ps=m.getParameterTypes();for(int i=0;i<args.length;i++)if(args[i]!=null&&!box(ps[i]).isInstance(args[i]))ok=false;if(ok){if(match!=null && !Arrays.equals(match.getParameterTypes(),m.getParameterTypes()))throw new IllegalStateException("Ambiguous "+name);if(match==null || (match.isBridge() && !m.isBridge()))match=m;}}
  if(match==null)throw new NoSuchMethodException(c.getName()+"."+name);return match.invoke(value instanceof Class?null:value,args);
 }
 static Object en(String name,String constant)throws Exception{for(Object e:type(name).getEnumConstants())if(e.toString().equals(constant))return e;throw new IllegalArgumentException(constant);}
 static void require(boolean condition,String message){if(!condition)throw new IllegalStateException(message);}
 static String hash(Path path)throws Exception{StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)))s.append(String.format("%02x",b&255));return s.toString();}
 static void log(String text)throws Exception{Files.write(ROOT.resolve("client-proof.txt"),(new Date().toInstant()+" "+text+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 static Map map(Object data,String name)throws Exception{return (Map)field(data,name);}
 static Object tag(Object data)throws Exception{Object t=type("net.minecraft.nbt.NBTTagCompound").newInstance();call(data,"func_76187_b",t);return t;}
 static void snapshot(Object data,String name)throws Exception{
  Object tag=tag(data);Method writer=null;for(Method m:type("net.minecraft.nbt.CompressedStreamTools").getMethods())if(Modifier.isStatic(m.getModifiers())&&m.getReturnType()==void.class&&Arrays.equals(m.getParameterTypes(),new Class<?>[]{tag.getClass(),OutputStream.class}))writer=m;
  require(writer!=null,"Compressed writer unavailable");Path p=ROOT.resolve(name+".dat");require(!Files.exists(p),"Snapshot already exists: "+p);try(OutputStream stream=Files.newOutputStream(p)){writer.invoke(null,tag,stream);}log("SNAPSHOT "+name+" sha256="+hash(p));
 }

 static Object world,global,player,server,isolated,adapter;
 static Properties ids;
 static final double DX=78080.5,DZ=66304.5,OX=48768.5,OZ=53632.5;
 static final String RECEIPT="KOMESeasonReturn";

 public static void main(String[] args)throws Exception{VirtualMachine v=VirtualMachine.attach(args[0]);try{v.loadAgent(args[1],args.length>2?args[2]:"before-human");}finally{v.detach();}}
 public static void agentmain(final String phase,Instrumentation ins)throws Exception{
  Class<?> mc=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("net.minecraft.client.Minecraft"))mc=c;require(mc!=null,"Not a client");loader=mc.getClassLoader();final Object client=call(mc,"func_71410_x");
  require(((File)field(client,"field_71412_D")).toPath().toRealPath().equals(Paths.get("C:/Users/dayne/AppData/Roaming/PrismLauncher/instances/kome-pr26-occupied-capital-20261010/minecraft").toRealPath()),"Wrong repaired profile");
  java.net.URL url=type("kome.common.KOMEAddon").getProtectionDomain().getCodeSource().getLocation();if("jar".equals(url.getProtocol()))url=((java.net.JarURLConnection)url.openConnection()).getJarFileURL();final String loadedHash=hash(Paths.get(url.toURI()));require(loadedHash.equals(new String(Files.readAllBytes(ROOT.resolve("repaired-candidate-sha256.txt")),StandardCharsets.UTF_8).trim()),"Wrong loaded client JAR");
  final Properties ids=new Properties();try(InputStream in=Files.newInputStream(ROOT.resolve("entity-network-ids.properties"))){ids.load(in);}Object proxy=field(type("kome.common.KOMEAddon"),"proxy");CountDownLatch done=new CountDownLatch(1);Throwable[] error={null};call(proxy,"enqueueClientTask",new Runnable(){public void run(){try{
   Object player=field(client,"field_71439_g"),world=field(client,"field_71441_e");require(player!=null&&world!=null&&PLAYER.equals(call(player,"func_110124_au")),"Authenticated connection missing");
   for(int i=1;i<=2;i++){Object rider=null,mount=null;int rc=0,mc=0;for(Object e:(List)field(world,"field_72996_f")){String id=call(e,"func_145782_y").toString();if(id.equals(ids.getProperty("networkRider"+i))){rider=e;rc++;}if(id.equals(ids.getProperty("networkMount"+i))){mount=e;mc++;}}require(rc==1&&mc==1,"Client UUID counts wrong "+rc+"/"+mc);require(field(rider,"field_70154_o")==mount&&field(mount,"field_70153_n")==rider,"Client attachment broken");require(Float.parseFloat(ids.getProperty("riderHP"+i))==(Float)call(rider,"func_110143_aJ")&&Float.parseFloat(ids.getProperty("mountHP"+i))==(Float)call(mount,"func_110143_aJ"),"Client partial HP differs");log("PASS "+phase+" CLIENT company="+ids.getProperty("company"+i)+" rider="+ids.getProperty("rider"+i)+" mount="+ids.getProperty("mount"+i)+" serverOriginalUUIDsCorrelatedByNetworkIds="+ids.getProperty("networkRider"+i)+"/"+ids.getProperty("networkMount"+i)+" clientEntityCounts=1/1 clientGeneratedHorseUUID="+call(mount,"func_110124_au")+" mounted=true partialHP="+call(rider,"func_110143_aJ")+"/"+call(mount,"func_110143_aJ")+" named="+call(rider,"func_94057_bL"));}
   log("PASS "+phase+" CONNECTED actualClientSHA256="+loadedHash+" identity="+PLAYER+" renderThread="+Thread.currentThread().getName()+" screen="+(field(client,"field_71462_r")==null?"world":field(client,"field_71462_r").getClass().getName())+" readOnly=true humanVisibilityPending=true");
  }catch(Throwable t){error[0]=t;try{log("FAIL "+t);}catch(Exception ignored){}}finally{done.countDown();}}});require(done.await(20,TimeUnit.SECONDS),"Client observer timeout");if(error[0]!=null)throw new RuntimeException(error[0]);
 }
}

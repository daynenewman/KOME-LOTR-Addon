from pathlib import Path
import datetime,hashlib,json,shutil,xml.etree.ElementTree as ET,zipfile
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def counts(folder):
 result=dict(discovered=0,passed=0,skipped=0,failures=0,errors=0)
 for path in folder.glob('TEST-*.xml'):
  t=ET.parse(path).getroot().attrib
  n,s,f,e=[int(t[k]) for k in ['tests','skipped','failures','errors']]
  for k,v in dict(discovered=n,passed=n-s-f-e,skipped=s,failures=f,errors=e).items():result[k]+=v
 assert result['discovered'] and result['failures']==result['errors']==0
 return result
candidate=json.loads((root/'candidate.json').read_text())
source=root.parent.parent/'source'
server=Path(candidate['server'])
client=Path(candidate['profile'])/'minecraft'
assert sha(server/'mods/KOME-LOTR-Addon-1.0.8.jar')==sha(client/'mods/KOME-LOTR-Addon-1.0.8.jar')==candidate['sha256']
assert all(sha(server/'config'/n)==sha(client/'config'/n)==h for n,h in candidate['config_hashes'].items())
proof=(root/'server-proof.txt').read_text()
assert 'PASS REPAIRED_RETURN C2' in proof and 'PASS REPAIRED_RETURN C3' in proof
assert 'PASS REPAIRED_RETRY clear landing' in proof
assert 'PASS retained governance CF1/C1/SUBMITTED' in proof
cp=(root/'client-proof.txt').read_text()
assert 'PASS before-human CLIENT company=C2' in cp and 'PASS before-human CLIENT company=C3' in cp
for src,dest in [(root/'runtime/console.log','repaired-console-at-staging.log'),(server/'logs/latest.log','repaired-server-at-staging.log'),(client/'logs/latest.log','repaired-client-at-staging.log')]:shutil.copy2(src,root/dest)
v={'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_parent':'4925e931f6909bf24a6cbdbd44290bfa51c1df67','dev':'f154deaed18ac3f1a7770ffa3bda8a88382a9e35',
 'candidate':candidate,'focused':counts(root/'focused-results'),'clean_test_build':counts(root/'clean-results'),
 'failure':{'candidate_sha256':'ec5181d81faa279a59fa228f3f830f6564e704ca631a533271b2dba3bac4c823','production_result':'FAIL_REPRODUCED_WITH_VALID_OBSERVED_ORIGIN_LOCATOR','first_exception':'IllegalStateException: Physical locator attached to an ineligible hired-unit state','cause':'Production reset retained T348 locator after changing rider/current company tile to T388; reset intent/checkpoint serialization refused that inconsistent state.','proof':'VALID_BASELINE at 17:09:18 followed by reset failure; g5-failed-console.log and controlled-baseline.dat retained','regression':'failed-before.xml: Persist locator invalidation before relocation expected null, but was KOMEHiredUnitPhysicalLocator'},
 'fix':'Use existing locator authority to clear the old address and checkpoint that invalidation before moveTree; normal live observation can verify the returned address. No protocol/schema/HP/governance changes.',
 'setup_attempts':[{'attempt':1,'result':'Immediate production return and retry passed; roof permitted a valid Y208 landing. Later exact-HP check failed after normal LOTR passive regeneration (one HP every 40 ticks, rider plus mount). Original raw evidence retained in attempt1. Not a reset healing defect.'},
 {'attempt':'V3','result':'Direct fixture reposition left a stale locator; fixture snapshot rejected that deliberately inconsistent setup. Preserved separately from genuine valid-baseline reset defect.'},
 {'attempt':'V4','result':'Both original records seeded through locator authority with valid T348 locators. Production reset then failed durably saving after return; genuine demonstrated defect.'},
 {'attempt':'client observer V1','result':'Incorrectly expected vanilla horse UUID transmission to client. Corrected observer correlates native server UUIDs to client via network entity ID and attachment. Original observer failure retained.'},
 {'attempt':'save-stop V5','result':'Source unit was unloaded, observer found null. Loading retained source chunks through existing native provider preserved original UUIDs; save and orderly stop then succeeded.'},
 {'attempt':'close-g5 client V1','result':'Disconnected KOME queue rejected validation shutdown task. Verified Minecraft shutdown only sets running=false; V2 orderly-closed the disconnected original profile.'}],
 'native_production':{'status':'PASS_SCOPED_RETURN_RETRY_AND_CONNECTED_SYNC','first_return':'C2 at capital reference X78080.5 Y200 Z66304.5',
 'second_return':'C3 valid clear X78078.5 Y200 Z66302.5','rider_mount_hp':{'C2':[3.25,7.125],'C3':[5.5,9.25]},
 'uuids':{'C2':{'rider':'21b42537-396e-4762-802f-56ec51c0258e','mount':'0f938b4d-6dbc-4de7-95bb-4c8609a7e20e'},'C3':{'rider':'e62ad6eb-941b-405a-af8b-dec982045b24','mount':'e7bec980-bf86-4101-bfe6-ac6067e86bbc'}},
 'once_only':'Two COMPANY_RETURN audits in durable isolated coordinator journal, one per company; identical journal and positions on coordinator/direct adapter retry; rider/mount tokens 1:C2 and 1:C3.',
 'native_tracking':'One original entity per UUID; player in native tracker sets; both client mounted trees correlated by entity IDs 302/303 and 324/325, matching exact HP.',
 'repaired_cold_load':'One new production JVM loads original saved rider/mount UUIDs and partial HP before client connects. This is retained fixture cold load, not a new full canonical season reset restart gate.',
 'pre_human_verify_label':'Probe mode verify prints RECONNECT; at 17:20:44 that is only pre-human staged-session verification. User reconnect remains pending and is not inferred from that label.'},
 'fixture_controls':{'journal':'Detached KOMEWorldData reset coordinator, checkpointResetFile in reset-journal.dat; production apply/moveTree/saveEntities reads real native Anvil chunks. Global war/governance/conflicts/ownership/capitals/reset journal unchanged.',
 'entities':'Direct API Campaign survivor setup, not paid recruitment. Same original four UUIDs throughout fixture adjustment and repaired cold load. Global Campaign records retain these survivors for ordinary tracking/reconnect.',
 'regeneration':'Validation-only LivingHealEvent listener cancels healing ONLY for four fixture UUIDs to measure exact partial HP. No config changes/class modification; not evidence of stock passive healing behavior.',
 'footprints':'New enclosed fixtures at dimension100: origin T348 X48768.5 Y200 Z53632.5, capital reference T388 X78080.5 Y200 Z66304.5; open roof after initial valid upper landing. Existing governance arena and original horse retained.'},
 'governance':'Prior human screenshot PASS retained on original g5 candidate; all governance/Join Battle/client/packet class hashes identical in repair. Native authority CF1/C1/SUBMITTED unchanged in repaired world; no human governance repeat.',
 'human':{'status':'PENDING','actions':'Disconnect/rejoin 127.0.0.1:51327; observe exactly two mounted soldiers at separate positions with no extra rider/horse or disconnect'},
 'limits':['One authenticated non-operator. Multiplayer deferred. No second account.','No new full global season reset, which would destroy the retained governance battle; isolated coordinator/real production physical returns are explicit.','Previous unchanged source/class evidence reused where applicable; this newly changed reset deployment is validated separately.','No dev merge/shared deployment; original g5 runtime/profile retained and frozen51326 untouched.']}
(root/'validation-native.json').write_text(json.dumps(v,indent=2)+'\n')
(root/'validation.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'focused':v['focused'],'clean':v['clean_test_build'],'candidate':candidate['sha256'],'human':'PENDING'}))

from pathlib import Path
import subprocess,time,json,hashlib,ctypes
r=Path(__file__).resolve().parent; server=r/'server'; java=Path('C:/Users/dayne/Documents/KOME-Validation/tile-resolution-20260918-200409-d095d7/server/java8')
assert not (r/'production-proof.txt').exists(), 'Retain prior proof and use a fresh isolated directory after failure'
assert hashlib.sha256((server/'mods/KOME-LOTR-Addon-1.0.8.jar').read_bytes()).hexdigest()=='263e8ff420b0e84c81f9b802a58b7d46182dee4158bfa41c60afc213b9e43eb0'
k=ctypes.windll.kernel32;k.CreateMutexW.restype=ctypes.c_void_p
mutex=k.CreateMutexW(None,False,'Local\\KOME-Heavy-Validation-686a-Child')
while k.WaitForSingleObject(ctypes.c_void_p(mutex),1000) not in (0,0x80):pass
p=None
try:
 with (r/'production-console.log').open('w',encoding='utf-8') as log:
  p=subprocess.Popen([str(java/'bin/java.exe'),'-Xms256M','-Xmx1280M','-Djava.awt.headless=true','-jar','forge-1.7.10-10.13.4.1614-1.7.10-universal.jar','nogui'],cwd=server,stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
  (r/'process.json').write_text(json.dumps({'pid':p.pid,'controller':__import__('os').getpid(),'server':str(server),'jar_sha256':'263e8ff420b0e84c81f9b802a58b7d46182dee4158bfa41c60afc213b9e43eb0','java':str(java)},indent=2)+'\n')
  print('Started isolated production loader PID '+str(p.pid),flush=True)
  deadline=time.monotonic()+150
  while time.monotonic()<deadline:
   if p.poll() is not None: raise RuntimeError('Production server exited before readiness')
   if 'Done (' in (r/'production-console.log').read_text(encoding='utf-8',errors='replace'):break
   time.sleep(.5)
  else:raise RuntimeError('Production readiness timeout')
  print('Native server ready; running guarded production probe',flush=True)
  a=subprocess.run([str(java/'bin/java.exe'),'-cp',str(r/'agent-classes')+';'+str(java/'lib/tools.jar'),'IntegrationProductionProbe',str(p.pid),str(r/'production-agent.jar')],capture_output=True,text=True,timeout=110)
  (r/'production-attach.log').write_text(a.stdout+a.stderr,encoding='utf-8')
  assert a.returncode==0, 'Native agent failed; see preserved attach/proof logs'
  proof=(r/'production-proof.txt').read_text();assert 'PASS production ' in proof and 'FAIL ' not in proof
  print(proof,flush=True)
 finally_marker=True
finally:
 if p and p.poll() is None:
  p.stdin.write('stop\n');p.stdin.flush()
  try:p.wait(timeout=60)
  except subprocess.TimeoutExpired: raise RuntimeError('Only this disposable production server needs orderly-stop follow-up')
 if p:(r/'exit.json').write_text(json.dumps({'exit_code':p.returncode})+'\n')
 k.ReleaseMutex(ctypes.c_void_p(mutex));k.CloseHandle(ctypes.c_void_p(mutex))

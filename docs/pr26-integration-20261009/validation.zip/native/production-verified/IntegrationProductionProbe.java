import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import com.sun.tools.attach.VirtualMachine;
/** Production-JAR linkage, native collision controls and isolated NBT. No connected player. */
public final class IntegrationProductionProbe {
 static final Path ROOT=Paths.get("C:/Users/dayne/.codex/worktrees/686a/KOME-LOTR-Addon/build/pr26-integration-20261009/production-verified");
 static ClassLoader cl;
 static Class<?> t(String n)throws Exception{return cl.loadClass(n);}
 static Object f(Object o,String n)throws Exception{return o.getClass().getField(n).get(o);}
 static void check(boolean b,String m)throws Exception{if(!b)throw new IllegalStateException(m);Files.write(ROOT.resolve("production-proof.txt"),("OK "+m+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}
 static Object call(Object o,String name,Object... args)throws Exception{Method chosen=null;for(Method m:o.getClass().getMethods())if(m.getName().equals(name)&&m.getParameterTypes().length==args.length){boolean match=true;Class<?>[] ps=m.getParameterTypes();for(int i=0;i<ps.length;i++)if(args[i]!=null&&!ps[i].isPrimitive()&&!ps[i].isInstance(args[i]))match=false;if(match){if(chosen!=null)throw new IllegalStateException("Ambiguous method "+name);chosen=m;}}if(chosen==null)throw new NoSuchMethodException(name);return chosen.invoke(o,args);}
 static boolean valid(Object result)throws Exception{return (Boolean)f(result,"valid");}
 static Object stored(Class<?> resolver,Object world,String method)throws Exception{
  Method m=resolver.getDeclaredMethod(method,t("net.minecraft.world.World"),String.class,int.class,double.class,double.class,double.class);m.setAccessible(true);return m.invoke(null,world,"T388",100,78016.5D,200D,66240.5D);
 }
 public static void main(String[] args)throws Exception{VirtualMachine vm=VirtualMachine.attach(args[0]);try{vm.loadAgent(args[1]);}finally{vm.detach();}}
 public static void agentmain(String ignored,Instrumentation ins)throws Exception{
  if(!Paths.get(System.getProperty("user.dir")).toRealPath().equals(ROOT.resolve("server").toRealPath()))throw new IllegalStateException("Wrong disposable runtime");
  Class<?> bridge=null;for(Class<?> c:ins.getAllLoadedClasses())if(c.getName().equals("AcceptanceTaskBridge"))bridge=c;
  if(bridge==null)throw new IllegalStateException("Missing native task bridge");cl=bridge.getClassLoader();
  CountDownLatch done=new CountDownLatch(1);Throwable[] failure=new Throwable[1];
  bridge.getMethod("enqueueServerTask",Runnable.class).invoke(null,new Runnable(){public void run(){try{
   check(Thread.currentThread().getName().equals("Server thread"),"native server thread and production LaunchClassLoader");
   Class<?> dm=t("net.minecraftforge.common.DimensionManager"),wc=t("net.minecraft.world.World"),entity=t("net.minecraft.entity.Entity");
   Object world=dm.getMethod("getWorld",int.class).invoke(null,100);if(world==null){dm.getMethod("initDimension",int.class).invoke(null,100);world=dm.getMethod("getWorld",int.class).invoke(null,100);}
   Object stone=t("net.minecraft.init.Blocks").getField("field_150348_b").get(null),air=t("net.minecraft.init.Blocks").getField("field_150350_a").get(null),water=t("net.minecraft.init.Blocks").getField("field_150355_j").get(null);
   Method block=wc.getMethod("func_147465_d",int.class,int.class,int.class,t("net.minecraft.block.Block"),int.class,int.class);
   for(int x=78010;x<=78022;x++)for(int z=66234;z<=66246;z++){block.invoke(world,x,199,z,stone,0,2);for(int y=200;y<=206;y++)block.invoke(world,x,y,z,air,0,2);}
   Class<?> resolver=t("kome.common.data.KOMEStrategicDeploymentResolver");
   check(valid(stored(resolver,world,"validateStored")),"unoccupied solid reference accepted");
   Object horse=t("net.minecraft.entity.passive.EntityHorse").getConstructor(wc).newInstance(world);
   entity.getMethod("func_70107_b",double.class,double.class,double.class).invoke(horse,78016.5D,200D,66240.5D);
   t("net.minecraft.entity.EntityLivingBase").getMethod("func_70606_j",float.class).invoke(horse,7.125F);
   check((Boolean)wc.getMethod("func_72838_d",entity).invoke(world,horse),"native blocking horse published");
   check(!valid(stored(resolver,world,"validateStored")),"ordinary capital and Join standing reference rejects occupied volume");
   check(valid(stored(resolver,world,"validateResetSearchOrigin")),"reset search reference permits existing survivor occupancy");
   Object safe=resolver.getMethod("resolveAround",wc,String.class,double.class,double.class,double.class,int.class,double.class,double.class).invoke(null,world,"T388",78016.5D,200D,66240.5D,24,1.4D,3.4D);
   check(valid(safe),"actual mounted landing finds free terrain with production SRG methods");
   Object anchor=f(safe,"anchor");check((Double)f(anchor,"x")!=78016.5D||(Double)f(anchor,"z")!=66240.5D,"actual landing keeps live-entity clearance");
   block.invoke(world,78016,200,66240,water,0,2);check(!valid(stored(resolver,world,"validateResetSearchOrigin")),"reset reference still rejects liquid");
   block.invoke(world,78016,200,66240,stone,0,2);check(!valid(stored(resolver,world,"validateResetSearchOrigin")),"reset reference still rejects block obstruction");block.invoke(world,78016,200,66240,air,0,2);
   Class<?> dataType=t("kome.common.data.KOMEWorldData");Object data=dataType.getConstructor(String.class).newInstance("isolated-production-integration");
   dataType.getMethod("initializeIntegratedWorld",wc).invoke(data,world);
   Object tag=t("net.minecraft.nbt.NBTTagCompound").newInstance();dataType.getMethod("func_76187_b",tag.getClass()).invoke(data,tag);
   check((Integer)call(tag,"func_74762_e","KOMEDataSchemaVersion")==12,"production root schema 12");
   check((Integer)call(tag,"func_74762_e","ConflictDataSchemaVersion")==2,"production ConflictData schema 2");
   Object restored=dataType.getConstructor(String.class).newInstance("isolated-production-reloaded");dataType.getMethod("func_76184_a",tag.getClass()).invoke(restored,tag);
   Object again=t("net.minecraft.nbt.NBTTagCompound").newInstance();dataType.getMethod("func_76187_b",again.getClass()).invoke(restored,again);   check(tag.equals(again),"production integrated root NBT round trip retained all authorities");
   check(t("kome.common.data.KOMEJoinBattleService$Reason").getField("GOVERNANCE_RESTRICTED")!=null,"new governance reason links in production");
   Files.write(ROOT.resolve("production-proof.txt"),"PASS production linkage/native collision controls/isolated NBT; no connected client or cold restart\n".getBytes(StandardCharsets.UTF_8),StandardOpenOption.APPEND);
  }catch(Throwable e){failure[0]=e;try{Files.write(ROOT.resolve("production-proof.txt"),("FAIL "+e+"\n").getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE,StandardOpenOption.APPEND);}catch(Exception ignored){}e.printStackTrace();}finally{done.countDown();}}});
  if(!done.await(90,TimeUnit.SECONDS))throw new IllegalStateException("Native task timed out");if(failure[0]!=null)throw new RuntimeException(failure[0]);
 }
}

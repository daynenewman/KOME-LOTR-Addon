param([string]$Label,[string[]]$GradleArgs)
$ErrorActionPreference='Stop'
$root=Join-Path $PSScriptRoot 'source'
$output=Join-Path $PSScriptRoot 'validation'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$parentController=Get-CimInstance Win32_Process -Filter 'ProcessId=43016'
$parentServer=Get-CimInstance Win32_Process -Filter 'ProcessId=30672'
$globalMutex=[System.Threading.Mutex]::new($false,'Local\KOME-Heavy-Validation')
$childMutex=[System.Threading.Mutex]::new($false,'Local\KOME-Heavy-Validation-686a-Child')
$globalOwned=$false
$childOwned=$false
try {
    try {$globalOwned=$globalMutex.WaitOne(0)} catch [System.Threading.AbandonedMutexException] {$globalOwned=$true}
    if (-not $globalOwned) {
        if (-not $parentController -or -not $parentServer -or $parentController.CommandLine -notlike '*reload-fix-runtime*controller.py*') {
            throw 'Global validation reservation has no verified same-task controller; refusing concurrent validation.'
        }
        $parentLog=Join-Path $PSScriptRoot '../pr-review-20261007/reload-fix-runtime/controller-cold-repaired.log'
        if (-not (Get-Content -LiteralPath $parentLog -Raw).Contains('Acquired Local\KOME-Heavy-Validation')) {
            throw 'Missing proof that the preserved controller owns the global reservation.'
        }
        Write-Output 'Using existing same-task Local\KOME-Heavy-Validation reservation: controller 43016/server 30672. Frozen acceptance untouched; one child validation at a time.'
    } else {Write-Output 'Acquired Local\KOME-Heavy-Validation'}
    while(-not $childOwned){try {$childOwned=$childMutex.WaitOne(1000)} catch [System.Threading.AbandonedMutexException] {$childOwned=$true}}
    $env:JAVA_HOME='C:/Users/dayne/.gradle/jdks/azul_systems__inc_-17-amd64-windows/zulu17.66.19-ca-fx-jdk17.0.19-win_x64'
    $env:GRADLE_USER_HOME='C:/Users/dayne/.gradle'
    $env:GRADLE_OPTS='-Dorg.gradle.jvmargs=-Xmx1g'
    Push-Location -LiteralPath $root
    try {
        & ./gradlew.bat @GradleArgs --offline --no-daemon --console=plain --max-workers=2 2>&1 | Tee-Object -FilePath (Join-Path $output ($Label+'.log'))
        $validationCode=$LASTEXITCODE
    } finally {Pop-Location}
    if($validationCode -ne 0){throw "Validation failed: $Label exit $validationCode"}
} finally {
    if($childOwned){$childMutex.ReleaseMutex()};$childMutex.Dispose()
    if($globalOwned){$globalMutex.ReleaseMutex()};$globalMutex.Dispose()
}

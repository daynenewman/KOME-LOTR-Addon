$ErrorActionPreference='Stop'
foreach($order in @('origin-first','destination-first')) {
 foreach($phase in @('first','recover','completed')) {
  & "$PSScriptRoot/validate.ps1" -Label "forge-reset-final-$order-$phase" -GradleArgs @('-I','../reset-final.gradle','runServer',"-PverificationOrder=$order","-PverificationPhase=$phase")
  if($LASTEXITCODE -ne 0){throw "Forge reset invocation failed $order $phase"}
 }
}
foreach($phase in @('first','restart')) {
 & "$PSScriptRoot/validate.ps1" -Label "forge-campaign-$phase" -GradleArgs @('-I','tools/campaign-lifecycle/verify-forge.gradle','runServer',"-PcampaignVerificationPhase=$phase")
 $proof=Join-Path $PSScriptRoot "source/build/campaign-lifecycle/forge/campaign-$phase.txt"
 $proofText=Get-Content -LiteralPath $proof -Raw
 if(-not $proofText.Contains("PASS phase=$phase;") -or $proofText.Contains('FAIL ')){throw "Missing campaign PASS proof $phase"}
 Write-Output "Verified campaign PASS proof: $phase"
}

from pathlib import Path
import subprocess, json, hashlib, zipfile

task = Path(__file__).resolve().parent
root = task/'source'
base = 'ff5053e56990dc601a1f0fe22d9e26e3affc1da0'
def git(*args):
    return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args])
def original(path): return git('show',base+':'+path)
def digest(data): return hashlib.sha256(data).hexdigest()
prefix = 'src/main/resources/assets/kome/config/'
r = 'kome_tile_route_defaults.csv'
m = 'kome_tile_route_markers.csv'
before_route = original(prefix+r)
before_marker = original(prefix+m)
assert before_route.count(b'T351,T352,river\n') == 1
assert before_marker.count(b'T351,T352,river,79488.0,80.0,55424.0,1431,1163\n') == 1
assert (root/(prefix+r)).read_bytes() == before_route.replace(b'T351,T352,river\n',b'T351,T352,open\n')
assert (root/(prefix+m)).read_bytes() == before_marker.replace(b'T351,T352,river,79488.0,80.0,55424.0,1431,1163\n',b'')
protected = ['src/test/resources/kome/tile/gameplay-baseline/production-paths.tsv',
 'src/test/resources/kome/tile/gameplay-baseline/mask.png',
 'src/main/resources/assets/kome/map/reset_conquest_tile_ids.png',
 'src/main/resources/assets/kome/map/reset_conquest_tile_ids.txt',
 'docs/gameplay-separation-implementation-20260919/original-derived.tsv',
 'docs/gameplay-separation-implementation-20260919/original-KOMEConquestTileDefaults.java.txt',
 'docs/gameplay-separation-implementation-20260919/export-baseline.py',
 prefix+'kome_tile_gameplay_points.csv', prefix+'kome_tile_waypoint_candidates.csv']
protected_hashes = {}
for path in protected:
    data = (root/path).read_bytes()
    baseline = original(path)
    assert data == baseline or data.replace(b'\r\n',b'\n') == baseline.replace(b'\r\n',b'\n'), path
    assert not git('diff','--name-only',base,'--',path).strip(), path
    protected_hashes[path] = {'git_sha256':digest(baseline),'checkout_sha256':digest(data),'byte_exact':data == baseline}
assert not git('diff','--name-only',base,'--','src/main/java','src/main/resources/assets/kome/map').strip()
manifest = dict(line.split('=',1) for line in (root/(prefix+'kome_tile_gameplay_manifest.properties')).read_text().splitlines())
provenance = json.loads((root/(prefix+'kome_tile_gameplay_provenance.json')).read_text())
resources = {}
for name, output in provenance['outputs'].items():
    data = (root/(prefix+name)).read_bytes()
    assert digest(data) == manifest[name] == output['sha256'], name
    rows = [l for l in data.decode().splitlines() if l and not l.startswith('#')]
    assert len(rows)-1 == output['rows'], name
    resources[name] = {'sha256':digest(data),'rows':len(rows)-1}
jars = {}
for path in sorted((root/'build/libs').glob('KOME-LOTR-Addon-*.jar')):
    with zipfile.ZipFile(path) as archive:
        for name in [r,m,'kome_tile_gameplay_manifest.properties','kome_tile_gameplay_provenance.json']:
            assert archive.read('assets/kome/config/'+name) == (root/(prefix+name)).read_bytes(), str(path)+' '+name
        assert archive.read('assets/kome/map/reset_conquest_tile_ids.png') == original('src/main/resources/assets/kome/map/reset_conquest_tile_ids.png')
    jars[path.name] = {'sha256':digest(path.read_bytes()),'bytes':path.stat().st_size,'exact_packaged_resources':True}
report = {'base_dev':base,'revision':manifest['revision'],'single_edge_single_marker_delta_exact':True,
 'production_java_and_map_unchanged':True,'protected_input_sha256':protected_hashes,'resource_hashes':resources,'built_artifacts':jars}
(task/'audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

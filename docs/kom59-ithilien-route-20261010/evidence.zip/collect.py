from pathlib import Path
import subprocess, json, hashlib, zipfile, datetime, xml.etree.ElementTree as ET

task=Path(__file__).resolve().parent
root=task/'source'
out=root/'docs/kom59-ithilien-route-20261010'
def git(*args): return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args],text=True).strip()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def results(path):
    totals={k:0 for k in ['tests','failures','errors','skipped']}
    suites=[]; skips=[]; failures=[]
    for file in sorted(path.glob('TEST-*.xml')):
        suite=ET.parse(file).getroot()
        count={k:int(suite.attrib.get(k,0)) for k in totals}
        for k in totals: totals[k]+=count[k]
        suites.append({'suite':suite.attrib['name'],**count})
        for case in suite.findall('testcase'):
            name=case.attrib['classname']+'.'+case.attrib['name']
            if case.find('skipped') is not None: skips.append(name)
            for fail in case.findall('failure'): failures.append({'case':name,'message':fail.attrib['message']})
    totals['passed']=totals['tests']-totals['failures']-totals['errors']-totals['skipped']
    return {'counts':totals,'suites':suites,'skips':skips,'failures':failures}
all_results={name:results(path) for name,path in {
 'focused-2':task/'validation/focused-2-results',
 'focused-3':task/'validation/focused-3-results',
 'focused-4':task/'validation/focused-4-results',
 'clean-test-build':root/'build/test-results/test'}.items()}
assert all_results['focused-4']['counts']=={'tests':32,'failures':0,'errors':0,'skipped':0,'passed':32}
assert all_results['clean-test-build']['counts']=={'tests':3090,'failures':0,'errors':0,'skipped':5,'passed':3085}
assert 'BUILD SUCCESSFUL' in (task/'validation/clean-test-build.log').read_text()
assert 'PASS:' in (task/'validation/routing-check.log').read_text()
assert (task/'protected-before.json').read_bytes()==(task/'protected-after.json').read_bytes()
setup_failures=[
 {'stage':'initial local clone','cause':'Git dubious ownership on primary .git','resolution':'Retried with command-scoped safe.directory for that source; no global configuration changed.'},
 {'stage':'documentation patch','cause':'Expected historical heading did not match; atomic patch rejected before modifications','resolution':'Read actual heading and reapplied exact patch.'},
 {'stage':'focused-1','cause':'Access denied to installed Gradle wrapper .zip.lck in filesystem sandbox','resolution':'Retried using authorized cache access and real-user same-session mutex reservation; original log retained.'},
 {'stage':'initial byte audit','cause':'Git blob versus CRLF checkout differed for unmodified text mapping','resolution':'Audit checks unchanged Git diff plus newline-aware equality for ordinary text; binary raster and -text golden/resources remain byte-exact.'},
 {'stage':'focused-2','cause':'Fixture left NextStepAvailableMillis zero; existing loader normalized it to NextStepDepartureMillis=12345','resolution':'Fixture now supplies both canonical timestamps. No production fix needed.'},
 {'stage':'focused-3','cause':'Fixture company lacked owner UUID; existing loader excludes ownerless companies','resolution':'Fixture now supplies matching company/order owner UUID and canonical movement link. No production fix needed.'},
 {'stage':'routing-check-1','cause':'Backticked ff5053e... SHA parsed as an unknown code identifier','resolution':'Use bold SHA text, consistent with routing provenance conventions; checker unchanged.'}
]
(task/'failed-operations.json').write_text(json.dumps(setup_failures,indent=2)+'\n',encoding='utf-8')
zip_path=out/'evidence.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted((task/'validation').rglob('*')):
        if file.is_file() and file.suffix in {'.log','.xml'}:
            z.write(file,'validation/'+str(file.relative_to(task/'validation')).replace('\\','/'))
    for file in sorted((root/'build/test-results/test').glob('TEST-*.xml')):
        z.write(file,'validation/clean-test-build-results/'+file.name)
    for name in ['failed-operations.json','audit.json','validate.ps1','audit.py','collect.py']:
        z.write(task/name,name)
    z.writestr('junit-summary.json',json.dumps(all_results,indent=2)+'\n')
audit=json.loads((task/'audit.json').read_text())
state=json.loads((task/'protected-after.json').read_text())
tree=git('write-tree')
report={
 'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_dev':audit['base_dev'],'branch':git('branch','--show-current'),
 'validated_src_git_tree':git('rev-parse',tree+':src'),
 'source_identity_note':'PR head is supplied in the PR description; its src tree must equal this validated tree. Git-version generation is disabled. Evidence/docs-only additions do not change compiled inputs.',
 'runtime':'Minecraft 1.7.10 / Forge 10.13.4.1614 / LOTR v36.15; Gradle 8.5, JDK 17.0.19 build launcher, existing Java 8 mod target; JUnit 4.13.2',
 'classpath_inputs':{p.name:sha(p) for p in sorted((root/'libs').glob('*.jar'))},
 'commands':{
  'focused':"gradlew.bat test --tests kome.common.data.KOMEIthilienRouteCorrectionTest --tests kome.common.data.KOMETileGameplayParityTest --tests kome.common.data.KOMETileGameplayDefaultsTest --tests kome.common.command.KOMEMountainBarrierMovementTest --tests kome.common.command.KOMEMovementDepartureGuardTest --offline --no-daemon --console=plain --max-workers=2",
  'clean':'gradlew.bat clean test build --offline --no-daemon --console=plain --max-workers=2',
  'docs':'python -B docs/routing/validate.py; git diff --check',
  'artifact':'audit.py exact byte delta, protected inputs, manifest/provenance checksums, and both built JAR resource readback'},
 'coordination':'Existing same-session Local\\KOME-Heavy-Validation reservation: frozen controller 43016/server 30672 and associated child controller 47800/server 22264 verified. Serialized offline work uses Local\\KOME-Heavy-Validation-686a-Leaf. No server command, restart, attach, replacement or world operation.',
 'results':{name:result['counts'] for name,result in all_results.items()},
 'skipped_tests':all_results['clean-test-build']['skips'],
 'focused_requirement_checks':{name:'PASS (JUnit production path)' for name in ['authorized direct routes both directions','saved river and blocked overrides after reload','normal origin and destination permissions','queued T352-T358-T351 route unchanged after repeated reload','automatic river marker absent']},
 'parity':'Historical golden SHA-256 unchanged; both comparisons apply checked exact edge replacement + marker deletion, then strictly compare all 6054 resulting rows under baseline/current raster.',
 'resource_and_artifact_audit':audit,
 'routing_check':(task/'validation/routing-check.log').read_text().strip(),
 'whitespace_check':'PASS working diff; staged and base-to-head repeated before publication',
 'retained_failures':setup_failures,
 'preservation':{'worktrees_checked':len(state['worktrees']),'worktree_heads_branches_statuses_unchanged':True,'local_heads_stash_refs_unchanged':True,'runtime_file_hashes_checked':len(state['runtime_files']),'runtime_file_hashes_unchanged':True,'runtime_process_ids':[p['Id'] for p in state['runtime_processes']],'runtime_start_times_unchanged':True,'world_operations':0},
 'evidence_zip':{'name':zip_path.name,'sha256':sha(zip_path),'bytes':zip_path.stat().st_size},
 'limitations':['No disposable Forge launch or live client/human check. JUnit invokes actual command BFS, departure authority and transactional WorldData NBT reload using test fixtures.','Actual generated terrain and reported server artifact/overrides/permissions remain unverified.','Multiplayer deferred. KOM-58/59 other geography decisions remain unresolved.','Saved overrides and stored queued routes are not migrated. No merge, shared deployment, runtime replacement or branch deletion.']}
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'src_tree':report['validated_src_git_tree'],'results':report['results'],'artifact':audit['built_artifacts'],'evidence':report['evidence_zip']},indent=2))

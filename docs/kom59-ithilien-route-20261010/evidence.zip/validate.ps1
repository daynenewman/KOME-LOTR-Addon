param([string]$Label, [string[]]$GradleArgs)
$ErrorActionPreference='Stop'
$output=Join-Path $PSScriptRoot 'validation'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$globalMutex=[System.Threading.Mutex]::new($false,'Local\KOME-Heavy-Validation')
$leafMutex=[System.Threading.Mutex]::new($false,'Local\KOME-Heavy-Validation-686a-Leaf')
$globalOwned=$false
$leafOwned=$false
try {
    try {$globalOwned=$globalMutex.WaitOne(0)} catch [System.Threading.AbandonedMutexException] {$globalOwned=$true}
    if (-not $globalOwned) {
        $frozen=Get-CimInstance Win32_Process -Filter 'ProcessId=43016'
        $associated=Get-CimInstance Win32_Process -Filter 'ProcessId=47800'
        Get-Process -Id 30672,22264 -ErrorAction Stop | Out-Null
        $workspace=Split-Path (Split-Path $PSScriptRoot)
        $proof=Join-Path $workspace 'build/pr-review-20261007/reload-fix-runtime/controller-cold-repaired.log'
        if (-not $frozen -or $frozen.CommandLine -notlike '*reload-fix-runtime/controller.py cold-repaired*' -or
            -not $associated -or $associated.CommandLine -notlike '*occupied-capital/runtime/controller.py*' -or
            -not (Get-Content -LiteralPath $proof -Raw).Contains('Acquired Local\KOME-Heavy-Validation')) {
            throw 'Global reservation lacks verified same-session acceptance controllers; refusing validation'
        }
        Write-Output 'Using retained same-session global reservation (43016/30672), associated child runtime (47800/22264); serialized offline leaf only. Both servers untouched.'
    } else { Write-Output 'Acquired Local\KOME-Heavy-Validation' }
    while (-not $leafOwned) {try {$leafOwned=$leafMutex.WaitOne(1000)} catch [System.Threading.AbandonedMutexException] {$leafOwned=$true}}
    $env:JAVA_HOME='C:/Users/dayne/.gradle/jdks/azul_systems__inc_-17-amd64-windows/zulu17.66.19-ca-fx-jdk17.0.19-win_x64'
    $env:GRADLE_USER_HOME='C:/Users/dayne/.gradle'
    $env:GRADLE_OPTS='-Dorg.gradle.jvmargs=-Xmx1g'
    Push-Location (Join-Path $PSScriptRoot 'source')
    try {
        & ./gradlew.bat @GradleArgs --offline --no-daemon --console=plain --max-workers=2 2>&1 | Tee-Object -FilePath (Join-Path $output ($Label+'.log'))
        $validationCode=$LASTEXITCODE
    } finally {Pop-Location}
    if ($validationCode -ne 0) {throw "Validation failed: $Label exit $validationCode"}
} finally {
    if ($leafOwned) {$leafMutex.ReleaseMutex()}; $leafMutex.Dispose()
    if ($globalOwned) {$globalMutex.ReleaseMutex()}; $globalMutex.Dispose()
}
